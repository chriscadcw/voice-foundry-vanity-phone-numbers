"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.vanityPhoneNumberHandler = void 0;
/*
This code retrieves the phone number from the associated contact flow
and attempts to derive the 5 "best"[1] vanity numbers from that phone number
and store the results a dynamoDB table tied to the original phone number

[1] "best" is determined to be the closest verbal representation of a number
    that does not contain offensive or slanderous words, this output can not
    be 100% guarenteed as new words are added to the offsensive list constantly
 */
const AWS = require("aws-sdk");
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const words = require('an-array-of-english-words');
/**
 * Function name: validateNumber
 * @param number string
 *
 * @return string
 *
 * Inside the function:
 * 1. Validates that the number can be processed
 * 2. If it is not a number, or the number is empty, throws an error 'Phone number was null or undefined'
 * 3. If the number is not a valid number, throws an error 'Invalid phone number.'
 * 4. If the number passes validation, returns the output from processPhoneNumber()
 */
const validateNumber = (number) => {
    // Uses a standard expression to match valid, ten digit US phone numbers
    const validPhoneNumber = /^(\+1|1)?\d{10}$/;
    if (!number) {
        throw Error("Phone number was null or undefined");
    }
    if (!number.match(validPhoneNumber)) {
        throw Error("Invalid phone number");
    }
    return processPhoneNumber(number);
};
/**
 * Function name: processPhoneNumber
 * @param phoneNumber string
 *
 * @return string
 *
 * Inside the function:
 * 1. Strips the country code or leading '1' off of the phone number and returns the remaining 10-digit number.
 */
const processPhoneNumber = (phoneNumber) => {
    // The regex to use to separate the country code from the rest of the phone number
    const phoneRegex = /^(\+1|1)?(\d{10})$/;
    // Returns only the last 10 digits of the phone number
    return phoneNumber.replace(phoneRegex, '$2');
};
/**
 * Function name: save
 * @param phoneNumber string
 * @param vanityList string[]
 * @param ddb DynamoDBDocumentClient
 *
 * Inside the function:
 * 1. Set up the parameters to use to save the number to the dynamo database
 * 2. Saves the data to the database and returns the promise frm the transaction
 */
const save = async (phoneNumber, vanityList, ddb) => {
    // Build the parameters to make the request
    const params = {
        TableName: 'vanity_numbers',
        Item: {
            phone_number: phoneNumber,
            vanity_numbers: vanityList
        },
        ConditionExpresion: 'attribute_not_exists(phone_number)',
        ReturnConsumedCapacity: 'TOTAL'
    };
    await ddb.send(new lib_dynamodb_1.PutCommand(params));
};
/**
 * Function name: generateVanityPhoneNumbers
 * @param number string
 * @param ddb DynamoDBDocumentClient
 *
 * @return Promise<string[]>
 *
 * Inside the function:
 * 1. Checks the database to determine if a vanity list already exists
 * 2. If a vanity list exists, return that vanity list <= Returns out of the function
 * 3. If no vanity list exists, instantiate a new vanityList
 * 4. Split the phone number into the firstThree and lastSeven numbers (will use lastSeven to create vanity)
 * 5. Set up array map with keypad mappings
 * 6. Split the specific key mappings for each number into arrays
 * 7. Itterate over nested arrays to create string combinations based on the numbers received
 * 8. Add the first 5 permitations as 'throw away' permitations (i.e. will usually be something like 1111111)
 * 9. After the first 5, check if the number exists in the array of English
 *    words provided by the 'an-array-of-english-words' package, if it does,
 *    add it to the vanityList array
 * 10. Pull the last 5 matches from the vanityList
 * 11. Store those matches in the database
 * 12. Return the matches *
 */
const generateVanityPhoneNumbers = async (number, ddb) => {
    var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l;
    let vanityList = await checkDatabase(number, ddb);
    if (vanityList != undefined && vanityList.length > 0) {
        // The vanity list already exists in the database, so return it
        return vanityList;
    }
    vanityList = [];
    // Pulls the first three digits from the phone number
    const firstThree = number.slice(0, 3);
    // Pulls the last seven numbers from the phone number
    const lastSeven = number.slice(3).split('');
    const letterMap = new Map([
        ['0', '0'],
        ['1', '1'],
        ['2', 'ABC'],
        ['3', 'DEF'],
        ['4', 'GHI'],
        ['5', 'JKL'],
        ['6', 'MNO'],
        ['7', 'PQRS'],
        ['8', 'TUV'],
        ['9', 'WXYZ']
    ]);
    const spotOneStr = (_a = letterMap.get(lastSeven[0])) === null || _a === void 0 ? void 0 : _a.split('');
    const spotTwoStr = (_b = letterMap.get(lastSeven[1])) === null || _b === void 0 ? void 0 : _b.split('');
    const spotThreeStr = (_c = letterMap.get(lastSeven[2])) === null || _c === void 0 ? void 0 : _c.split('');
    const spotFourStr = (_d = letterMap.get(lastSeven[3])) === null || _d === void 0 ? void 0 : _d.split('');
    const spotFiveStr = (_e = letterMap.get(lastSeven[4])) === null || _e === void 0 ? void 0 : _e.split('');
    const spotSixStr = (_f = letterMap.get(lastSeven[5])) === null || _f === void 0 ? void 0 : _f.split('');
    const spotSevenStr = (_g = letterMap.get(lastSeven[6])) === null || _g === void 0 ? void 0 : _g.split('');
    // Check if any of the string arrays are empty, which means that the lastSeven didn't pick up all of the values
    if (spotOneStr == undefined || spotTwoStr == undefined || spotThreeStr == undefined || spotFourStr == undefined ||
        spotFiveStr == undefined || spotSixStr == undefined || spotSevenStr == undefined) {
        throw new Error("Unable to retrieve all number strings.");
    }
    // Loop through each groups of letters to create a combination string from each group of letters
    // At each iteration and sub iteration, we check to see if the list has been completed and if so
    //  break out to the previous level 
    for (let i = 0; i < spotOneStr.length; i++) {
        if (vanityList.length >= 5) {
            // list already contains the 5 words
            break;
        }
        for (let j = 0; j < spotTwoStr.length; j++) {
            if (vanityList.length >= 5) {
                // list already contains the 5 words
                break;
            }
            for (let k = 0; k < spotThreeStr.length; k++) {
                if (vanityList.length >= 5) {
                    // list already contains the 5 words
                    break;
                }
                for (let m = 0; m < spotFourStr.length; m++) {
                    if (vanityList.length >= 5) {
                        // list already contains the 5 words
                        break;
                    }
                    for (let n = 0; n < spotFiveStr.length; n++) {
                        if (vanityList.length >= 5) {
                            // list already contains the 5 words
                            break;
                        }
                        for (let p = 0; p < spotSixStr.length; p++) {
                            if (vanityList.length >= 5) {
                                // list already contains the 5 words
                                break;
                            }
                            for (let q = 0; q < spotSevenStr.length; q++) {
                                if (vanityList.length >= 5) {
                                    // list already contains the 5 words
                                    break;
                                }
                                const phoneWord = spotOneStr[i] + spotTwoStr[j] + spotThreeStr[k] + spotFourStr[m] + spotFiveStr[n] + spotSixStr[p] + spotSevenStr[q];
                                const vanityNumber = firstThree + phoneWord;
                                if (words.includes(phoneWord.toLowerCase())) {
                                    // If the combinations of letters from the 7 characters forms a word, add it to the list
                                    vanityList.push(vanityNumber);
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    // If there were no combinations found using the full seven digit string,
    // We'll attempt a search based on just the last four instead
    if (vanityList.length == 0) { // The default list length of nonsense combinations is 7                        
        // Pulls the first six digits from the phone number
        const firstSix = number.slice(0, 6);
        // Pulls only the last four digits from the phone number
        const lastFour = number.slice(6).split('');
        const retrySpotOneStr = (_h = letterMap.get(lastFour[0])) === null || _h === void 0 ? void 0 : _h.split('');
        const retrySpotTwoStr = (_j = letterMap.get(lastFour[1])) === null || _j === void 0 ? void 0 : _j.split('');
        const retrySpotThreeStr = (_k = letterMap.get(lastFour[2])) === null || _k === void 0 ? void 0 : _k.split('');
        const retrySpotFourStr = (_l = letterMap.get(lastFour[3])) === null || _l === void 0 ? void 0 : _l.split('');
        // Check if any of the string arrays are empty, which means that the lastSeven didn't pick up all of the values
        if (retrySpotOneStr == undefined || retrySpotTwoStr == undefined || retrySpotThreeStr == undefined || retrySpotFourStr == undefined) {
            throw new Error("Unable to retrieve all number strings.");
        }
        // Loop through each combination of digits to attempt to find words
        for (let i = 0; i < retrySpotOneStr.length; i++) {
            // If the vanity list is full, we'll stop the loop
            if (vanityList.length >= 5) {
                break;
            }
            for (let j = 0; j < retrySpotTwoStr.length; j++) {
                // If the vanity list is full, we'll stop the loop
                if (vanityList.length >= 5) {
                    break;
                }
                for (let k = 0; k < retrySpotThreeStr.length; k++) {
                    // If the vanity list is full, we'll stop the loop
                    if (vanityList.length >= 5) {
                        break;
                    }
                    for (let m = 0; m < retrySpotFourStr.length; m++) {
                        // If the vanity list is full, we'll stop the loop
                        if (vanityList.length >= 5) {
                            break;
                        }
                        const phoneWord = retrySpotOneStr[i] + retrySpotTwoStr[j] + retrySpotThreeStr[k] + retrySpotFourStr[m];
                        const vanityNumber = firstSix + phoneWord;
                        // If the vanity word created by the last four digits is in the words list, add it to the vanity list
                        if (words.includes(phoneWord.toLowerCase())) {
                            vanityList.push(vanityNumber);
                        }
                    }
                }
            }
        }
    }
    if (vanityList.length > 0) {
        await save(number, vanityList, ddb);
    }
    return vanityList;
};
/**
 * Function name: checkDatabse
 * @param number string
 * @param ddb DynamoDBDocumentClient
 *
 * @return Promise<string[]>
 *
 * Inside the function:
 * 1. Makes a request to the database for the incoming phone number
 *    to see if there is a record stored already
 * 2. If there is a record already stored, return the record
 * 3. Else, return an empty array in the promise
 */
const checkDatabase = async (number, ddb) => {
    var _a, _b;
    const params = {
        TableName: 'vanity_numbers',
        Key: {
            phone_number: number
        }
    };
    let results = [];
    try {
        const result = await ddb.send(new lib_dynamodb_1.GetCommand(params));
        if (((_a = result.Item) === null || _a === void 0 ? void 0 : _a.vanity_numbers) != undefined) {
            results = (_b = result.Item) === null || _b === void 0 ? void 0 : _b.vanity_numbers;
        }
    }
    catch (err) {
        throw new Error("Encountered an error while trying to request existing records: " + err);
    }
    return results;
};
/**
 * Function name: vanityPhoneNumberHandler
 * @param event ConnectContactFlowEvent
 * @param context Context
 * @param callback ConnectContactFlowCallback
 *
 * @return string
 *
 * Inside the function:
 */
exports.vanityPhoneNumberHandler = async (event, context, callback) => {
    var _a, _b, _c;
    AWS.config.update({ region: process.env.AWS_REGION });
    const dynamoDB = new client_dynamodb_1.DynamoDBClient({});
    const ddb = lib_dynamodb_1.DynamoDBDocumentClient.from(dynamoDB);
    try {
        const phoneNumber = (_c = (_b = (_a = event.Details) === null || _a === void 0 ? void 0 : _a.ContactData) === null || _b === void 0 ? void 0 : _b.CustomerEndpoint) === null || _c === void 0 ? void 0 : _c.Address;
        if (phoneNumber == undefined) {
            throw new Error('Unable to get event details from ConnectContactFlowEvent');
        }
        const validatedNumber = validateNumber(phoneNumber);
        const vanityList = await generateVanityPhoneNumbers(validatedNumber, ddb);
        const result = {};
        if (vanityList.length > 0) {
            const finalVanityList = vanityList.slice(-3); // We're only returning the last 3 matches to the user
            for (let i = 0; i < finalVanityList.length; i++) {
                result['number' + i] = finalVanityList[i].replace(/(.)/g, '$&, ');
            }
        }
        let status = '';
        if (result['number0'] !== 'undefined') {
            status = 'Success!';
        }
        else {
            status = 'No matches found.';
        }
        callback(null, result);
        return status;
    }
    catch (err) {
        const status = 'Failure!';
        callback(err);
        return status;
    }
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibGFtYmRhLXZhbml0eS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImxhbWJkYS12YW5pdHkudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUE7Ozs7Ozs7O0dBUUc7QUFDSCwrQkFBK0I7QUFDL0IsOERBQTBEO0FBQzFELHdEQUF1RjtBQUd2RixNQUFNLEtBQUssR0FBWSxPQUFPLENBQUMsMkJBQTJCLENBQUMsQ0FBQztBQUU1RDs7Ozs7Ozs7Ozs7R0FXRztBQUNILE1BQU0sY0FBYyxHQUFHLENBQUMsTUFBYyxFQUFVLEVBQUU7SUFDOUMsd0VBQXdFO0lBQ3hFLE1BQU0sZ0JBQWdCLEdBQUcsa0JBQWtCLENBQUM7SUFFNUMsSUFBSSxDQUFDLE1BQU0sRUFBRTtRQUNULE1BQU0sS0FBSyxDQUFDLG9DQUFvQyxDQUFDLENBQUM7S0FDckQ7SUFFRCxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxFQUFFO1FBQ2pDLE1BQU0sS0FBSyxDQUFDLHNCQUFzQixDQUFDLENBQUM7S0FDdkM7SUFFRCxPQUFPLGtCQUFrQixDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQ3RDLENBQUMsQ0FBQTtBQUVEOzs7Ozs7OztHQVFHO0FBQ0gsTUFBTSxrQkFBa0IsR0FBRyxDQUFDLFdBQW1CLEVBQVUsRUFBRTtJQUN2RCxrRkFBa0Y7SUFDbEYsTUFBTSxVQUFVLEdBQUcsb0JBQW9CLENBQUM7SUFFeEMsc0RBQXNEO0lBQ3RELE9BQU8sV0FBVyxDQUFDLE9BQU8sQ0FBRSxVQUFVLEVBQUUsSUFBSSxDQUFFLENBQUM7QUFDbkQsQ0FBQyxDQUFBO0FBRUQ7Ozs7Ozs7OztHQVNHO0FBQ0gsTUFBTSxJQUFJLEdBQUcsS0FBSyxFQUFFLFdBQW1CLEVBQUUsVUFBb0IsRUFBRSxHQUEyQixFQUFHLEVBQUU7SUFFM0YsMkNBQTJDO0lBQzNDLE1BQU0sTUFBTSxHQUFRO1FBQ2hCLFNBQVMsRUFBRSxnQkFBZ0I7UUFDM0IsSUFBSSxFQUFFO1lBQ0YsWUFBWSxFQUFFLFdBQVc7WUFDekIsY0FBYyxFQUFFLFVBQVU7U0FDN0I7UUFDRCxrQkFBa0IsRUFBRSxvQ0FBb0M7UUFDeEQsc0JBQXNCLEVBQUUsT0FBTztLQUNsQyxDQUFDO0lBRUYsTUFBTSxHQUFHLENBQUMsSUFBSSxDQUNWLElBQUkseUJBQVUsQ0FBQyxNQUFNLENBQUMsQ0FDekIsQ0FBQTtBQUNMLENBQUMsQ0FBQTtBQUVEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0dBc0JHO0FBQ0gsTUFBTSwwQkFBMEIsR0FBRyxLQUFLLEVBQUUsTUFBYyxFQUFFLEdBQTJCLEVBQXFCLEVBQUU7O0lBQ3hHLElBQUksVUFBVSxHQUFhLE1BQU0sYUFBYSxDQUFDLE1BQU0sRUFBRSxHQUFHLENBQUMsQ0FBQztJQUU1RCxJQUFHLFVBQVUsSUFBSSxTQUFTLElBQUksVUFBVSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUM7UUFDaEQsK0RBQStEO1FBQy9ELE9BQU8sVUFBVSxDQUFDO0tBQ3JCO0lBRUQsVUFBVSxHQUFHLEVBQUUsQ0FBQztJQUVoQixxREFBcUQ7SUFDckQsTUFBTSxVQUFVLEdBQUcsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUM7SUFDckMscURBQXFEO0lBQ3JELE1BQU0sU0FBUyxHQUFHLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDO0lBRTVDLE1BQU0sU0FBUyxHQUFHLElBQUksR0FBRyxDQUFDO1FBQ3RCLENBQUMsR0FBRyxFQUFFLEdBQUcsQ0FBQztRQUNWLENBQUMsR0FBRyxFQUFFLEdBQUcsQ0FBQztRQUNWLENBQUMsR0FBRyxFQUFFLEtBQUssQ0FBQztRQUNaLENBQUMsR0FBRyxFQUFFLEtBQUssQ0FBQztRQUNaLENBQUMsR0FBRyxFQUFFLEtBQUssQ0FBQztRQUNaLENBQUMsR0FBRyxFQUFFLEtBQUssQ0FBQztRQUNaLENBQUMsR0FBRyxFQUFFLEtBQUssQ0FBQztRQUNaLENBQUMsR0FBRyxFQUFFLE1BQU0sQ0FBQztRQUNiLENBQUMsR0FBRyxFQUFFLEtBQUssQ0FBQztRQUNaLENBQUMsR0FBRyxFQUFFLE1BQU0sQ0FBQztLQUNoQixDQUFDLENBQUM7SUFFSCxNQUFNLFVBQVUsU0FBRyxTQUFTLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQywwQ0FBRSxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUU7SUFDM0QsTUFBTSxVQUFVLFNBQUcsU0FBUyxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsMENBQUUsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDO0lBQzFELE1BQU0sWUFBWSxTQUFHLFNBQVMsQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLDBDQUFFLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQztJQUM1RCxNQUFNLFdBQVcsU0FBRyxTQUFTLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQywwQ0FBRSxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUM7SUFDM0QsTUFBTSxXQUFXLFNBQUcsU0FBUyxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsMENBQUUsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDO0lBQzNELE1BQU0sVUFBVSxTQUFHLFNBQVMsQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLDBDQUFFLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQztJQUMxRCxNQUFNLFlBQVksU0FBRyxTQUFTLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQywwQ0FBRSxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUM7SUFFNUQsK0dBQStHO0lBQy9HLElBQUksVUFBVSxJQUFJLFNBQVMsSUFBSSxVQUFVLElBQUksU0FBUyxJQUFJLFlBQVksSUFBSSxTQUFTLElBQUksV0FBVyxJQUFJLFNBQVM7UUFDM0csV0FBVyxJQUFJLFNBQVMsSUFBSSxVQUFVLElBQUksU0FBUyxJQUFJLFlBQVksSUFBSSxTQUFTLEVBQUU7UUFDOUUsTUFBTSxJQUFJLEtBQUssQ0FBQyx3Q0FBd0MsQ0FBQyxDQUFDO0tBQzdEO0lBRUwsZ0dBQWdHO0lBQ2hHLGdHQUFnRztJQUNoRyxvQ0FBb0M7SUFDcEMsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFVBQVUsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7UUFDeEMsSUFBSSxVQUFVLENBQUMsTUFBTSxJQUFJLENBQUMsRUFBRTtZQUN4QixvQ0FBb0M7WUFDcEMsTUFBTTtTQUNUO1FBRUQsS0FBTSxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFVBQVUsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDekMsSUFBSSxVQUFVLENBQUMsTUFBTSxJQUFJLENBQUMsRUFBRTtnQkFDeEIsb0NBQW9DO2dCQUNwQyxNQUFNO2FBQ1Q7WUFFRCxLQUFNLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsWUFBWSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtnQkFDM0MsSUFBSSxVQUFVLENBQUMsTUFBTSxJQUFJLENBQUMsRUFBRTtvQkFDeEIsb0NBQW9DO29CQUNwQyxNQUFNO2lCQUNUO2dCQUVELEtBQU0sSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxXQUFXLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO29CQUMxQyxJQUFJLFVBQVUsQ0FBQyxNQUFNLElBQUksQ0FBQyxFQUFFO3dCQUN4QixvQ0FBb0M7d0JBQ3BDLE1BQU07cUJBQ1Q7b0JBRUQsS0FBTSxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFdBQVcsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7d0JBQzFDLElBQUksVUFBVSxDQUFDLE1BQU0sSUFBSSxDQUFDLEVBQUU7NEJBQ3hCLG9DQUFvQzs0QkFDcEMsTUFBTTt5QkFDVDt3QkFFRCxLQUFNLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsVUFBVSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTs0QkFDekMsSUFBSSxVQUFVLENBQUMsTUFBTSxJQUFJLENBQUMsRUFBRTtnQ0FDeEIsb0NBQW9DO2dDQUNwQyxNQUFNOzZCQUNUOzRCQUVELEtBQU0sSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxZQUFZLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO2dDQUMzQyxJQUFJLFVBQVUsQ0FBQyxNQUFNLElBQUksQ0FBQyxFQUFFO29DQUN4QixvQ0FBb0M7b0NBQ3BDLE1BQU07aUNBQ1Q7Z0NBRUQsTUFBTSxTQUFTLEdBQUcsVUFBVSxDQUFDLENBQUMsQ0FBQyxHQUFHLFVBQVUsQ0FBQyxDQUFDLENBQUMsR0FBRyxZQUFZLENBQUMsQ0FBQyxDQUFDLEdBQUcsV0FBVyxDQUFDLENBQUMsQ0FBQyxHQUFHLFdBQVcsQ0FBQyxDQUFDLENBQUMsR0FBRyxVQUFVLENBQUMsQ0FBQyxDQUFDLEdBQUcsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDO2dDQUN0SSxNQUFNLFlBQVksR0FBRyxVQUFVLEdBQUcsU0FBUyxDQUFDO2dDQUM1QyxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLFdBQVcsRUFBRSxDQUFFLEVBQUU7b0NBQzFDLHdGQUF3RjtvQ0FDeEYsVUFBVSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQztpQ0FDakM7NkJBQ0o7eUJBQ0o7cUJBQ0o7aUJBQ0o7YUFDSjtTQUNKO0tBQ0o7SUFDRCx5RUFBeUU7SUFDekUsNkRBQTZEO0lBQzdELElBQUksVUFBVSxDQUFDLE1BQU0sSUFBSSxDQUFDLEVBQUcsRUFBRSxnRkFBZ0Y7UUFDM0csbURBQW1EO1FBQ25ELE1BQU0sUUFBUSxHQUFHLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ25DLHdEQUF3RDtRQUN4RCxNQUFNLFFBQVEsR0FBRyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUUzQyxNQUFNLGVBQWUsU0FBRyxTQUFTLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQywwQ0FBRSxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUU7UUFDL0QsTUFBTSxlQUFlLFNBQUcsU0FBUyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsMENBQUUsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBQzlELE1BQU0saUJBQWlCLFNBQUcsU0FBUyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsMENBQUUsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBQ2hFLE1BQU0sZ0JBQWdCLFNBQUcsU0FBUyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsMENBQUUsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBRS9ELCtHQUErRztRQUMvRyxJQUFJLGVBQWUsSUFBSSxTQUFTLElBQUksZUFBZSxJQUFJLFNBQVMsSUFBSSxpQkFBaUIsSUFBSSxTQUFTLElBQUksZ0JBQWdCLElBQUksU0FBUyxFQUFFO1lBQ2pJLE1BQU0sSUFBSSxLQUFLLENBQUMsd0NBQXdDLENBQUMsQ0FBQztTQUM3RDtRQUVELG1FQUFtRTtRQUNuRSxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsZUFBZSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUM3QyxrREFBa0Q7WUFDbEQsSUFBSSxVQUFVLENBQUMsTUFBTSxJQUFJLENBQUMsRUFBRTtnQkFDeEIsTUFBTTthQUNUO1lBRUQsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLGVBQWUsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7Z0JBQzdDLGtEQUFrRDtnQkFDbEQsSUFBSSxVQUFVLENBQUMsTUFBTSxJQUFJLENBQUMsRUFBRTtvQkFDeEIsTUFBTTtpQkFDVDtnQkFFRCxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsaUJBQWlCLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO29CQUMvQyxrREFBa0Q7b0JBQ2xELElBQUksVUFBVSxDQUFDLE1BQU0sSUFBSSxDQUFDLEVBQUU7d0JBQ3hCLE1BQU07cUJBQ1Q7b0JBRUQsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLGdCQUFnQixDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTt3QkFDOUMsa0RBQWtEO3dCQUNsRCxJQUFJLFVBQVUsQ0FBQyxNQUFNLElBQUksQ0FBQyxFQUFFOzRCQUN4QixNQUFNO3lCQUNUO3dCQUNELE1BQU0sU0FBUyxHQUFHLGVBQWUsQ0FBQyxDQUFDLENBQUMsR0FBRyxlQUFlLENBQUMsQ0FBQyxDQUFDLEdBQUcsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLEdBQUcsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQ3ZHLE1BQU0sWUFBWSxHQUFHLFFBQVEsR0FBRyxTQUFTLENBQUM7d0JBQzFDLHFHQUFxRzt3QkFDckcsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxFQUFFOzRCQUN6QyxVQUFVLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDO3lCQUNqQztxQkFFSjtpQkFDSjthQUNKO1NBQ0o7S0FDSjtJQUVELElBQUksVUFBVSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7UUFDdkIsTUFBTSxJQUFJLENBQUMsTUFBTSxFQUFFLFVBQVUsRUFBRSxHQUFHLENBQUMsQ0FBQztLQUN2QztJQUVELE9BQU8sVUFBVSxDQUFDO0FBRXRCLENBQUMsQ0FBQTtBQUVEOzs7Ozs7Ozs7Ozs7R0FZRztBQUNILE1BQU0sYUFBYSxHQUFHLEtBQUssRUFBRSxNQUFjLEVBQUUsR0FBMkIsRUFBcUIsRUFBRTs7SUFFM0YsTUFBTSxNQUFNLEdBQUc7UUFDWCxTQUFTLEVBQUUsZ0JBQWdCO1FBQzNCLEdBQUcsRUFBRTtZQUNELFlBQVksRUFBRSxNQUFNO1NBQ3ZCO0tBQ0osQ0FBQztJQUVGLElBQUksT0FBTyxHQUFhLEVBQUUsQ0FBQztJQUUzQixJQUFJO1FBQ0EsTUFBTSxNQUFNLEdBQUcsTUFBTSxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUkseUJBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO1FBQ3RELElBQUksT0FBQSxNQUFNLENBQUMsSUFBSSwwQ0FBRSxjQUFjLEtBQUksU0FBUyxFQUFFO1lBQzFDLE9BQU8sU0FBRyxNQUFNLENBQUMsSUFBSSwwQ0FBRSxjQUFjLENBQUM7U0FDekM7S0FDSjtJQUFDLE9BQU0sR0FBRyxFQUFDO1FBQ1IsTUFBTSxJQUFJLEtBQUssQ0FBQyxpRUFBaUUsR0FBRyxHQUFHLENBQUMsQ0FBQztLQUM1RjtJQUVELE9BQU8sT0FBTyxDQUFDO0FBQ25CLENBQUMsQ0FBQTtBQUdEOzs7Ozs7Ozs7R0FTRztBQUNVLFFBQUEsd0JBQXdCLEdBQUcsS0FBSyxFQUFHLEtBQThCLEVBQUUsT0FBZ0IsRUFBRSxRQUFvQyxFQUFFLEVBQUU7O0lBQ3RJLEdBQUcsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsTUFBTSxFQUFFLE9BQU8sQ0FBQyxHQUFHLENBQUMsVUFBVSxFQUFFLENBQUMsQ0FBQztJQUV0RCxNQUFNLFFBQVEsR0FBRyxJQUFJLGdDQUFjLENBQUMsRUFBRSxDQUFDLENBQUM7SUFDeEMsTUFBTSxHQUFHLEdBQUcscUNBQXNCLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO0lBRWxELElBQUk7UUFDQSxNQUFNLFdBQVcscUJBQUcsS0FBSyxDQUFDLE9BQU8sMENBQUUsV0FBVywwQ0FBRSxnQkFBZ0IsMENBQUUsT0FBTyxDQUFDO1FBQzFFLElBQUksV0FBVyxJQUFJLFNBQVMsRUFBQztZQUN6QixNQUFNLElBQUksS0FBSyxDQUFDLDBEQUEwRCxDQUFDLENBQUM7U0FDL0U7UUFFRCxNQUFNLGVBQWUsR0FBRyxjQUFjLENBQUMsV0FBVyxDQUFDLENBQUM7UUFFcEQsTUFBTSxVQUFVLEdBQUcsTUFBTSwwQkFBMEIsQ0FBQyxlQUFlLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFFMUUsTUFBTSxNQUFNLEdBQTZCLEVBQUUsQ0FBQztRQUU1QyxJQUFJLFVBQVUsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO1lBQ3ZCLE1BQU0sZUFBZSxHQUFHLFVBQVUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLHNEQUFzRDtZQUVwRyxLQUFNLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsZUFBZSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtnQkFDOUMsTUFBTSxDQUFDLFFBQVEsR0FBRyxDQUFDLENBQUMsR0FBRyxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLE1BQU0sRUFBRSxNQUFNLENBQUMsQ0FBQzthQUNyRTtTQUNKO1FBRUQsSUFBSSxNQUFNLEdBQUcsRUFBRSxDQUFDO1FBQ2hCLElBQUksTUFBTSxDQUFDLFNBQVMsQ0FBQyxLQUFLLFdBQVcsRUFBQztZQUNsQyxNQUFNLEdBQUcsVUFBVSxDQUFDO1NBQ3ZCO2FBQU07WUFDSCxNQUFNLEdBQUcsbUJBQW1CLENBQUM7U0FDaEM7UUFDRCxRQUFRLENBQUMsSUFBSSxFQUFFLE1BQU0sQ0FBQyxDQUFDO1FBQ3ZCLE9BQU8sTUFBTSxDQUFDO0tBQ2pCO0lBQUMsT0FBTyxHQUFHLEVBQUM7UUFDVCxNQUFNLE1BQU0sR0FBRyxVQUFVLENBQUM7UUFDMUIsUUFBUSxDQUFDLEdBQVksQ0FBQyxDQUFDO1FBQ3ZCLE9BQU8sTUFBTSxDQUFDO0tBQ2pCO0FBQ0wsQ0FBQyxDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiLypcclxuVGhpcyBjb2RlIHJldHJpZXZlcyB0aGUgcGhvbmUgbnVtYmVyIGZyb20gdGhlIGFzc29jaWF0ZWQgY29udGFjdCBmbG93XHJcbmFuZCBhdHRlbXB0cyB0byBkZXJpdmUgdGhlIDUgXCJiZXN0XCJbMV0gdmFuaXR5IG51bWJlcnMgZnJvbSB0aGF0IHBob25lIG51bWJlclxyXG5hbmQgc3RvcmUgdGhlIHJlc3VsdHMgYSBkeW5hbW9EQiB0YWJsZSB0aWVkIHRvIHRoZSBvcmlnaW5hbCBwaG9uZSBudW1iZXJcclxuXHJcblsxXSBcImJlc3RcIiBpcyBkZXRlcm1pbmVkIHRvIGJlIHRoZSBjbG9zZXN0IHZlcmJhbCByZXByZXNlbnRhdGlvbiBvZiBhIG51bWJlclxyXG4gICAgdGhhdCBkb2VzIG5vdCBjb250YWluIG9mZmVuc2l2ZSBvciBzbGFuZGVyb3VzIHdvcmRzLCB0aGlzIG91dHB1dCBjYW4gbm90XHJcbiAgICBiZSAxMDAlIGd1YXJlbnRlZWQgYXMgbmV3IHdvcmRzIGFyZSBhZGRlZCB0byB0aGUgb2Zmc2Vuc2l2ZSBsaXN0IGNvbnN0YW50bHlcclxuICovXHJcbmltcG9ydCAqIGFzIEFXUyBmcm9tICdhd3Mtc2RrJztcclxuaW1wb3J0IHsgRHluYW1vREJDbGllbnQgfSBmcm9tICdAYXdzLXNkay9jbGllbnQtZHluYW1vZGInO1xyXG5pbXBvcnQgeyBEeW5hbW9EQkRvY3VtZW50Q2xpZW50LCBQdXRDb21tYW5kLCBHZXRDb21tYW5kIH0gZnJvbSAnQGF3cy1zZGsvbGliLWR5bmFtb2RiJztcclxuaW1wb3J0IHsgQ29ubmVjdENvbnRhY3RGbG93Q2FsbGJhY2ssIENvbm5lY3RDb250YWN0Rmxvd0V2ZW50LCBDb25uZWN0Q29udGFjdEZsb3dSZXN1bHQsIENvbnRleHQgfSBmcm9tICdhd3MtbGFtYmRhJztcclxuXHJcbmNvbnN0IHdvcmRzOnN0cmluZ1tdID0gcmVxdWlyZSgnYW4tYXJyYXktb2YtZW5nbGlzaC13b3JkcycpO1xyXG5cclxuLyoqXHJcbiAqIEZ1bmN0aW9uIG5hbWU6IHZhbGlkYXRlTnVtYmVyXHJcbiAqIEBwYXJhbSBudW1iZXIgc3RyaW5nXHJcbiAqXHJcbiAqIEByZXR1cm4gc3RyaW5nXHJcbiAqIFxyXG4gKiBJbnNpZGUgdGhlIGZ1bmN0aW9uOlxyXG4gKiAxLiBWYWxpZGF0ZXMgdGhhdCB0aGUgbnVtYmVyIGNhbiBiZSBwcm9jZXNzZWRcclxuICogMi4gSWYgaXQgaXMgbm90IGEgbnVtYmVyLCBvciB0aGUgbnVtYmVyIGlzIGVtcHR5LCB0aHJvd3MgYW4gZXJyb3IgJ1Bob25lIG51bWJlciB3YXMgbnVsbCBvciB1bmRlZmluZWQnXHJcbiAqIDMuIElmIHRoZSBudW1iZXIgaXMgbm90IGEgdmFsaWQgbnVtYmVyLCB0aHJvd3MgYW4gZXJyb3IgJ0ludmFsaWQgcGhvbmUgbnVtYmVyLidcclxuICogNC4gSWYgdGhlIG51bWJlciBwYXNzZXMgdmFsaWRhdGlvbiwgcmV0dXJucyB0aGUgb3V0cHV0IGZyb20gcHJvY2Vzc1Bob25lTnVtYmVyKClcclxuICovXHJcbmNvbnN0IHZhbGlkYXRlTnVtYmVyID0gKG51bWJlcjogc3RyaW5nKTogc3RyaW5nID0+IHtcclxuICAgIC8vIFVzZXMgYSBzdGFuZGFyZCBleHByZXNzaW9uIHRvIG1hdGNoIHZhbGlkLCB0ZW4gZGlnaXQgVVMgcGhvbmUgbnVtYmVyc1xyXG4gICAgY29uc3QgdmFsaWRQaG9uZU51bWJlciA9IC9eKFxcKzF8MSk/XFxkezEwfSQvO1xyXG5cclxuICAgIGlmKCAhbnVtYmVyICl7XHJcbiAgICAgICAgdGhyb3cgRXJyb3IoXCJQaG9uZSBudW1iZXIgd2FzIG51bGwgb3IgdW5kZWZpbmVkXCIpOyAgICBcclxuICAgIH1cclxuXHJcbiAgICBpZiggIW51bWJlci5tYXRjaCh2YWxpZFBob25lTnVtYmVyKSApe1xyXG4gICAgICAgIHRocm93IEVycm9yKFwiSW52YWxpZCBwaG9uZSBudW1iZXJcIik7XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIHByb2Nlc3NQaG9uZU51bWJlcihudW1iZXIpO1xyXG59XHJcblxyXG4vKipcclxuICogRnVuY3Rpb24gbmFtZTogcHJvY2Vzc1Bob25lTnVtYmVyXHJcbiAqIEBwYXJhbSBwaG9uZU51bWJlciBzdHJpbmdcclxuICpcclxuICogQHJldHVybiBzdHJpbmdcclxuICpcclxuICogSW5zaWRlIHRoZSBmdW5jdGlvbjpcclxuICogMS4gU3RyaXBzIHRoZSBjb3VudHJ5IGNvZGUgb3IgbGVhZGluZyAnMScgb2ZmIG9mIHRoZSBwaG9uZSBudW1iZXIgYW5kIHJldHVybnMgdGhlIHJlbWFpbmluZyAxMC1kaWdpdCBudW1iZXIuXHJcbiAqL1xyXG5jb25zdCBwcm9jZXNzUGhvbmVOdW1iZXIgPSAocGhvbmVOdW1iZXI6IHN0cmluZyk6IHN0cmluZyA9PiB7XHJcbiAgICAvLyBUaGUgcmVnZXggdG8gdXNlIHRvIHNlcGFyYXRlIHRoZSBjb3VudHJ5IGNvZGUgZnJvbSB0aGUgcmVzdCBvZiB0aGUgcGhvbmUgbnVtYmVyXHJcbiAgICBjb25zdCBwaG9uZVJlZ2V4ID0gL14oXFwrMXwxKT8oXFxkezEwfSkkLztcclxuXHJcbiAgICAvLyBSZXR1cm5zIG9ubHkgdGhlIGxhc3QgMTAgZGlnaXRzIG9mIHRoZSBwaG9uZSBudW1iZXJcclxuICAgIHJldHVybiBwaG9uZU51bWJlci5yZXBsYWNlKCBwaG9uZVJlZ2V4LCAnJDInICk7XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBGdW5jdGlvbiBuYW1lOiBzYXZlXHJcbiAqIEBwYXJhbSBwaG9uZU51bWJlciBzdHJpbmdcclxuICogQHBhcmFtIHZhbml0eUxpc3Qgc3RyaW5nW11cclxuICogQHBhcmFtIGRkYiBEeW5hbW9EQkRvY3VtZW50Q2xpZW50XHJcbiAqIFxyXG4gKiBJbnNpZGUgdGhlIGZ1bmN0aW9uOlxyXG4gKiAxLiBTZXQgdXAgdGhlIHBhcmFtZXRlcnMgdG8gdXNlIHRvIHNhdmUgdGhlIG51bWJlciB0byB0aGUgZHluYW1vIGRhdGFiYXNlXHJcbiAqIDIuIFNhdmVzIHRoZSBkYXRhIHRvIHRoZSBkYXRhYmFzZSBhbmQgcmV0dXJucyB0aGUgcHJvbWlzZSBmcm0gdGhlIHRyYW5zYWN0aW9uXHJcbiAqL1xyXG5jb25zdCBzYXZlID0gYXN5bmMgKHBob25lTnVtYmVyOiBzdHJpbmcsIHZhbml0eUxpc3Q6IHN0cmluZ1tdLCBkZGI6IER5bmFtb0RCRG9jdW1lbnRDbGllbnQgKSA9PiB7XHJcblxyXG4gICAgLy8gQnVpbGQgdGhlIHBhcmFtZXRlcnMgdG8gbWFrZSB0aGUgcmVxdWVzdFxyXG4gICAgY29uc3QgcGFyYW1zOiBhbnkgPSB7XHJcbiAgICAgICAgVGFibGVOYW1lOiAndmFuaXR5X251bWJlcnMnLFxyXG4gICAgICAgIEl0ZW06IHtcclxuICAgICAgICAgICAgcGhvbmVfbnVtYmVyOiBwaG9uZU51bWJlcixcclxuICAgICAgICAgICAgdmFuaXR5X251bWJlcnM6IHZhbml0eUxpc3RcclxuICAgICAgICB9LFxyXG4gICAgICAgIENvbmRpdGlvbkV4cHJlc2lvbjogJ2F0dHJpYnV0ZV9ub3RfZXhpc3RzKHBob25lX251bWJlciknLFxyXG4gICAgICAgIFJldHVybkNvbnN1bWVkQ2FwYWNpdHk6ICdUT1RBTCdcclxuICAgIH07XHJcblxyXG4gICAgYXdhaXQgZGRiLnNlbmQoXHJcbiAgICAgICAgbmV3IFB1dENvbW1hbmQocGFyYW1zKVxyXG4gICAgKVxyXG59XHJcblxyXG4vKipcclxuICogRnVuY3Rpb24gbmFtZTogZ2VuZXJhdGVWYW5pdHlQaG9uZU51bWJlcnNcclxuICogQHBhcmFtIG51bWJlciBzdHJpbmdcclxuICogQHBhcmFtIGRkYiBEeW5hbW9EQkRvY3VtZW50Q2xpZW50XHJcbiAqIFxyXG4gKiBAcmV0dXJuIFByb21pc2U8c3RyaW5nW10+XHJcbiAqIFxyXG4gKiBJbnNpZGUgdGhlIGZ1bmN0aW9uOlxyXG4gKiAxLiBDaGVja3MgdGhlIGRhdGFiYXNlIHRvIGRldGVybWluZSBpZiBhIHZhbml0eSBsaXN0IGFscmVhZHkgZXhpc3RzXHJcbiAqIDIuIElmIGEgdmFuaXR5IGxpc3QgZXhpc3RzLCByZXR1cm4gdGhhdCB2YW5pdHkgbGlzdCA8PSBSZXR1cm5zIG91dCBvZiB0aGUgZnVuY3Rpb25cclxuICogMy4gSWYgbm8gdmFuaXR5IGxpc3QgZXhpc3RzLCBpbnN0YW50aWF0ZSBhIG5ldyB2YW5pdHlMaXN0IFxyXG4gKiA0LiBTcGxpdCB0aGUgcGhvbmUgbnVtYmVyIGludG8gdGhlIGZpcnN0VGhyZWUgYW5kIGxhc3RTZXZlbiBudW1iZXJzICh3aWxsIHVzZSBsYXN0U2V2ZW4gdG8gY3JlYXRlIHZhbml0eSlcclxuICogNS4gU2V0IHVwIGFycmF5IG1hcCB3aXRoIGtleXBhZCBtYXBwaW5nc1xyXG4gKiA2LiBTcGxpdCB0aGUgc3BlY2lmaWMga2V5IG1hcHBpbmdzIGZvciBlYWNoIG51bWJlciBpbnRvIGFycmF5c1xyXG4gKiA3LiBJdHRlcmF0ZSBvdmVyIG5lc3RlZCBhcnJheXMgdG8gY3JlYXRlIHN0cmluZyBjb21iaW5hdGlvbnMgYmFzZWQgb24gdGhlIG51bWJlcnMgcmVjZWl2ZWRcclxuICogOC4gQWRkIHRoZSBmaXJzdCA1IHBlcm1pdGF0aW9ucyBhcyAndGhyb3cgYXdheScgcGVybWl0YXRpb25zIChpLmUuIHdpbGwgdXN1YWxseSBiZSBzb21ldGhpbmcgbGlrZSAxMTExMTExKVxyXG4gKiA5LiBBZnRlciB0aGUgZmlyc3QgNSwgY2hlY2sgaWYgdGhlIG51bWJlciBleGlzdHMgaW4gdGhlIGFycmF5IG9mIEVuZ2xpc2hcclxuICogICAgd29yZHMgcHJvdmlkZWQgYnkgdGhlICdhbi1hcnJheS1vZi1lbmdsaXNoLXdvcmRzJyBwYWNrYWdlLCBpZiBpdCBkb2VzLCBcclxuICogICAgYWRkIGl0IHRvIHRoZSB2YW5pdHlMaXN0IGFycmF5XHJcbiAqIDEwLiBQdWxsIHRoZSBsYXN0IDUgbWF0Y2hlcyBmcm9tIHRoZSB2YW5pdHlMaXN0XHJcbiAqIDExLiBTdG9yZSB0aG9zZSBtYXRjaGVzIGluIHRoZSBkYXRhYmFzZVxyXG4gKiAxMi4gUmV0dXJuIHRoZSBtYXRjaGVzICogXHJcbiAqL1xyXG5jb25zdCBnZW5lcmF0ZVZhbml0eVBob25lTnVtYmVycyA9IGFzeW5jIChudW1iZXI6IHN0cmluZywgZGRiOiBEeW5hbW9EQkRvY3VtZW50Q2xpZW50KTogUHJvbWlzZTxzdHJpbmdbXT4gPT4ge1xyXG4gICAgbGV0IHZhbml0eUxpc3Q6IHN0cmluZ1tdID0gYXdhaXQgY2hlY2tEYXRhYmFzZShudW1iZXIsIGRkYik7XHJcblxyXG4gICAgaWYodmFuaXR5TGlzdCAhPSB1bmRlZmluZWQgJiYgdmFuaXR5TGlzdC5sZW5ndGggPiAwKXtcclxuICAgICAgICAvLyBUaGUgdmFuaXR5IGxpc3QgYWxyZWFkeSBleGlzdHMgaW4gdGhlIGRhdGFiYXNlLCBzbyByZXR1cm4gaXRcclxuICAgICAgICByZXR1cm4gdmFuaXR5TGlzdDtcclxuICAgIH1cclxuXHJcbiAgICB2YW5pdHlMaXN0ID0gW107XHJcblxyXG4gICAgLy8gUHVsbHMgdGhlIGZpcnN0IHRocmVlIGRpZ2l0cyBmcm9tIHRoZSBwaG9uZSBudW1iZXJcclxuICAgIGNvbnN0IGZpcnN0VGhyZWUgPSBudW1iZXIuc2xpY2UoMCwzKTtcclxuICAgIC8vIFB1bGxzIHRoZSBsYXN0IHNldmVuIG51bWJlcnMgZnJvbSB0aGUgcGhvbmUgbnVtYmVyXHJcbiAgICBjb25zdCBsYXN0U2V2ZW4gPSBudW1iZXIuc2xpY2UoMykuc3BsaXQoJycpOyAgICAgICAgXHJcblxyXG4gICAgY29uc3QgbGV0dGVyTWFwID0gbmV3IE1hcChbXHJcbiAgICAgICAgWycwJywgJzAnXSxcclxuICAgICAgICBbJzEnLCAnMSddLFxyXG4gICAgICAgIFsnMicsICdBQkMnXSxcclxuICAgICAgICBbJzMnLCAnREVGJ10sXHJcbiAgICAgICAgWyc0JywgJ0dISSddLFxyXG4gICAgICAgIFsnNScsICdKS0wnXSxcclxuICAgICAgICBbJzYnLCAnTU5PJ10sXHJcbiAgICAgICAgWyc3JywgJ1BRUlMnXSxcclxuICAgICAgICBbJzgnLCAnVFVWJ10sXHJcbiAgICAgICAgWyc5JywgJ1dYWVonXVxyXG4gICAgXSk7XHJcblxyXG4gICAgY29uc3Qgc3BvdE9uZVN0ciA9IGxldHRlck1hcC5nZXQobGFzdFNldmVuWzBdKT8uc3BsaXQoJycpIDtcclxuICAgIGNvbnN0IHNwb3RUd29TdHIgPSBsZXR0ZXJNYXAuZ2V0KGxhc3RTZXZlblsxXSk/LnNwbGl0KCcnKTtcclxuICAgIGNvbnN0IHNwb3RUaHJlZVN0ciA9IGxldHRlck1hcC5nZXQobGFzdFNldmVuWzJdKT8uc3BsaXQoJycpO1xyXG4gICAgY29uc3Qgc3BvdEZvdXJTdHIgPSBsZXR0ZXJNYXAuZ2V0KGxhc3RTZXZlblszXSk/LnNwbGl0KCcnKTtcclxuICAgIGNvbnN0IHNwb3RGaXZlU3RyID0gbGV0dGVyTWFwLmdldChsYXN0U2V2ZW5bNF0pPy5zcGxpdCgnJyk7XHJcbiAgICBjb25zdCBzcG90U2l4U3RyID0gbGV0dGVyTWFwLmdldChsYXN0U2V2ZW5bNV0pPy5zcGxpdCgnJyk7XHJcbiAgICBjb25zdCBzcG90U2V2ZW5TdHIgPSBsZXR0ZXJNYXAuZ2V0KGxhc3RTZXZlbls2XSk/LnNwbGl0KCcnKTtcclxuXHJcbiAgICAvLyBDaGVjayBpZiBhbnkgb2YgdGhlIHN0cmluZyBhcnJheXMgYXJlIGVtcHR5LCB3aGljaCBtZWFucyB0aGF0IHRoZSBsYXN0U2V2ZW4gZGlkbid0IHBpY2sgdXAgYWxsIG9mIHRoZSB2YWx1ZXNcclxuICAgIGlmKCBzcG90T25lU3RyID09IHVuZGVmaW5lZCB8fCBzcG90VHdvU3RyID09IHVuZGVmaW5lZCB8fCBzcG90VGhyZWVTdHIgPT0gdW5kZWZpbmVkIHx8IHNwb3RGb3VyU3RyID09IHVuZGVmaW5lZCB8fCBcclxuICAgICAgICBzcG90Rml2ZVN0ciA9PSB1bmRlZmluZWQgfHwgc3BvdFNpeFN0ciA9PSB1bmRlZmluZWQgfHwgc3BvdFNldmVuU3RyID09IHVuZGVmaW5lZCApe1xyXG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJVbmFibGUgdG8gcmV0cmlldmUgYWxsIG51bWJlciBzdHJpbmdzLlwiKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgLy8gTG9vcCB0aHJvdWdoIGVhY2ggZ3JvdXBzIG9mIGxldHRlcnMgdG8gY3JlYXRlIGEgY29tYmluYXRpb24gc3RyaW5nIGZyb20gZWFjaCBncm91cCBvZiBsZXR0ZXJzXHJcbiAgICAvLyBBdCBlYWNoIGl0ZXJhdGlvbiBhbmQgc3ViIGl0ZXJhdGlvbiwgd2UgY2hlY2sgdG8gc2VlIGlmIHRoZSBsaXN0IGhhcyBiZWVuIGNvbXBsZXRlZCBhbmQgaWYgc29cclxuICAgIC8vICBicmVhayBvdXQgdG8gdGhlIHByZXZpb3VzIGxldmVsIFxyXG4gICAgZm9yKCBsZXQgaSA9IDA7IGkgPCBzcG90T25lU3RyLmxlbmd0aDsgaSsrICl7XHJcbiAgICAgICAgaWYoIHZhbml0eUxpc3QubGVuZ3RoID49IDUgKXtcclxuICAgICAgICAgICAgLy8gbGlzdCBhbHJlYWR5IGNvbnRhaW5zIHRoZSA1IHdvcmRzXHJcbiAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgIH1cclxuICAgICAgICBcclxuICAgICAgICBmb3IgKCBsZXQgaiA9IDA7IGogPCBzcG90VHdvU3RyLmxlbmd0aDsgaisrICl7XHJcbiAgICAgICAgICAgIGlmKCB2YW5pdHlMaXN0Lmxlbmd0aCA+PSA1ICl7XHJcbiAgICAgICAgICAgICAgICAvLyBsaXN0IGFscmVhZHkgY29udGFpbnMgdGhlIDUgd29yZHNcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICBmb3IgKCBsZXQgayA9IDA7IGsgPCBzcG90VGhyZWVTdHIubGVuZ3RoOyBrKysgKXtcclxuICAgICAgICAgICAgICAgIGlmKCB2YW5pdHlMaXN0Lmxlbmd0aCA+PSA1ICl7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gbGlzdCBhbHJlYWR5IGNvbnRhaW5zIHRoZSA1IHdvcmRzXHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgZm9yICggbGV0IG0gPSAwOyBtIDwgc3BvdEZvdXJTdHIubGVuZ3RoOyBtKysgKXtcclxuICAgICAgICAgICAgICAgICAgICBpZiggdmFuaXR5TGlzdC5sZW5ndGggPj0gNSApe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBsaXN0IGFscmVhZHkgY29udGFpbnMgdGhlIDUgd29yZHNcclxuICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICBmb3IgKCBsZXQgbiA9IDA7IG4gPCBzcG90Rml2ZVN0ci5sZW5ndGg7IG4rKyApe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiggdmFuaXR5TGlzdC5sZW5ndGggPj0gNSApe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gbGlzdCBhbHJlYWR5IGNvbnRhaW5zIHRoZSA1IHdvcmRzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgZm9yICggbGV0IHAgPSAwOyBwIDwgc3BvdFNpeFN0ci5sZW5ndGg7IHArKyApe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYoIHZhbml0eUxpc3QubGVuZ3RoID49IDUgKXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBsaXN0IGFscmVhZHkgY29udGFpbnMgdGhlIDUgd29yZHNcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb3IgKCBsZXQgcSA9IDA7IHEgPCBzcG90U2V2ZW5TdHIubGVuZ3RoOyBxKysgKXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiggdmFuaXR5TGlzdC5sZW5ndGggPj0gNSApe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBsaXN0IGFscmVhZHkgY29udGFpbnMgdGhlIDUgd29yZHNcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBwaG9uZVdvcmQgPSBzcG90T25lU3RyW2ldICsgc3BvdFR3b1N0cltqXSArIHNwb3RUaHJlZVN0cltrXSArIHNwb3RGb3VyU3RyW21dICsgc3BvdEZpdmVTdHJbbl0gKyBzcG90U2l4U3RyW3BdICsgc3BvdFNldmVuU3RyW3FdO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHZhbml0eU51bWJlciA9IGZpcnN0VGhyZWUgKyBwaG9uZVdvcmQ7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYoIHdvcmRzLmluY2x1ZGVzKHBob25lV29yZC50b0xvd2VyQ2FzZSgpICkgKXsgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gSWYgdGhlIGNvbWJpbmF0aW9ucyBvZiBsZXR0ZXJzIGZyb20gdGhlIDcgY2hhcmFjdGVycyBmb3JtcyBhIHdvcmQsIGFkZCBpdCB0byB0aGUgbGlzdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YW5pdHlMaXN0LnB1c2godmFuaXR5TnVtYmVyKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9ICAgIFxyXG4gICAgLy8gSWYgdGhlcmUgd2VyZSBubyBjb21iaW5hdGlvbnMgZm91bmQgdXNpbmcgdGhlIGZ1bGwgc2V2ZW4gZGlnaXQgc3RyaW5nLFxyXG4gICAgLy8gV2UnbGwgYXR0ZW1wdCBhIHNlYXJjaCBiYXNlZCBvbiBqdXN0IHRoZSBsYXN0IGZvdXIgaW5zdGVhZFxyXG4gICAgaWYoIHZhbml0eUxpc3QubGVuZ3RoID09IDAgKSB7IC8vIFRoZSBkZWZhdWx0IGxpc3QgbGVuZ3RoIG9mIG5vbnNlbnNlIGNvbWJpbmF0aW9ucyBpcyA3ICAgICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgLy8gUHVsbHMgdGhlIGZpcnN0IHNpeCBkaWdpdHMgZnJvbSB0aGUgcGhvbmUgbnVtYmVyXHJcbiAgICAgICAgY29uc3QgZmlyc3RTaXggPSBudW1iZXIuc2xpY2UoMCw2KTtcclxuICAgICAgICAvLyBQdWxscyBvbmx5IHRoZSBsYXN0IGZvdXIgZGlnaXRzIGZyb20gdGhlIHBob25lIG51bWJlclxyXG4gICAgICAgIGNvbnN0IGxhc3RGb3VyID0gbnVtYmVyLnNsaWNlKDYpLnNwbGl0KCcnKTsgICAgICAgIFxyXG5cclxuICAgICAgICBjb25zdCByZXRyeVNwb3RPbmVTdHIgPSBsZXR0ZXJNYXAuZ2V0KGxhc3RGb3VyWzBdKT8uc3BsaXQoJycpIDtcclxuICAgICAgICBjb25zdCByZXRyeVNwb3RUd29TdHIgPSBsZXR0ZXJNYXAuZ2V0KGxhc3RGb3VyWzFdKT8uc3BsaXQoJycpO1xyXG4gICAgICAgIGNvbnN0IHJldHJ5U3BvdFRocmVlU3RyID0gbGV0dGVyTWFwLmdldChsYXN0Rm91clsyXSk/LnNwbGl0KCcnKTtcclxuICAgICAgICBjb25zdCByZXRyeVNwb3RGb3VyU3RyID0gbGV0dGVyTWFwLmdldChsYXN0Rm91clszXSk/LnNwbGl0KCcnKTtcclxuXHJcbiAgICAgICAgLy8gQ2hlY2sgaWYgYW55IG9mIHRoZSBzdHJpbmcgYXJyYXlzIGFyZSBlbXB0eSwgd2hpY2ggbWVhbnMgdGhhdCB0aGUgbGFzdFNldmVuIGRpZG4ndCBwaWNrIHVwIGFsbCBvZiB0aGUgdmFsdWVzXHJcbiAgICAgICAgaWYoIHJldHJ5U3BvdE9uZVN0ciA9PSB1bmRlZmluZWQgfHwgcmV0cnlTcG90VHdvU3RyID09IHVuZGVmaW5lZCB8fCByZXRyeVNwb3RUaHJlZVN0ciA9PSB1bmRlZmluZWQgfHwgcmV0cnlTcG90Rm91clN0ciA9PSB1bmRlZmluZWQgKXtcclxuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiVW5hYmxlIHRvIHJldHJpZXZlIGFsbCBudW1iZXIgc3RyaW5ncy5cIik7XHJcbiAgICAgICAgfSBcclxuXHJcbiAgICAgICAgLy8gTG9vcCB0aHJvdWdoIGVhY2ggY29tYmluYXRpb24gb2YgZGlnaXRzIHRvIGF0dGVtcHQgdG8gZmluZCB3b3Jkc1xyXG4gICAgICAgIGZvciggbGV0IGkgPSAwOyBpIDwgcmV0cnlTcG90T25lU3RyLmxlbmd0aDsgaSsrICl7XHJcbiAgICAgICAgICAgIC8vIElmIHRoZSB2YW5pdHkgbGlzdCBpcyBmdWxsLCB3ZSdsbCBzdG9wIHRoZSBsb29wXHJcbiAgICAgICAgICAgIGlmKCB2YW5pdHlMaXN0Lmxlbmd0aCA+PSA1ICl7XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgZm9yKCBsZXQgaiA9IDA7IGogPCByZXRyeVNwb3RUd29TdHIubGVuZ3RoOyBqKysgKXtcclxuICAgICAgICAgICAgICAgIC8vIElmIHRoZSB2YW5pdHkgbGlzdCBpcyBmdWxsLCB3ZSdsbCBzdG9wIHRoZSBsb29wXHJcbiAgICAgICAgICAgICAgICBpZiggdmFuaXR5TGlzdC5sZW5ndGggPj0gNSApe1xyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIGZvciggbGV0IGsgPSAwOyBrIDwgcmV0cnlTcG90VGhyZWVTdHIubGVuZ3RoOyBrKysgKXtcclxuICAgICAgICAgICAgICAgICAgICAvLyBJZiB0aGUgdmFuaXR5IGxpc3QgaXMgZnVsbCwgd2UnbGwgc3RvcCB0aGUgbG9vcFxyXG4gICAgICAgICAgICAgICAgICAgIGlmKCB2YW5pdHlMaXN0Lmxlbmd0aCA+PSA1ICl7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgZm9yKCBsZXQgbSA9IDA7IG0gPCByZXRyeVNwb3RGb3VyU3RyLmxlbmd0aDsgbSsrICl7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIElmIHRoZSB2YW5pdHkgbGlzdCBpcyBmdWxsLCB3ZSdsbCBzdG9wIHRoZSBsb29wXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmKCB2YW5pdHlMaXN0Lmxlbmd0aCA+PSA1ICl7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBwaG9uZVdvcmQgPSByZXRyeVNwb3RPbmVTdHJbaV0gKyByZXRyeVNwb3RUd29TdHJbal0gKyByZXRyeVNwb3RUaHJlZVN0cltrXSArIHJldHJ5U3BvdEZvdXJTdHJbbV07ICAgICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHZhbml0eU51bWJlciA9IGZpcnN0U2l4ICsgcGhvbmVXb3JkOyAgICAgICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBJZiB0aGUgdmFuaXR5IHdvcmQgY3JlYXRlZCBieSB0aGUgbGFzdCBmb3VyIGRpZ2l0cyBpcyBpbiB0aGUgd29yZHMgbGlzdCwgYWRkIGl0IHRvIHRoZSB2YW5pdHkgbGlzdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiggd29yZHMuaW5jbHVkZXMocGhvbmVXb3JkLnRvTG93ZXJDYXNlKCkpICl7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YW5pdHlMaXN0LnB1c2godmFuaXR5TnVtYmVyKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICBcclxuICAgIGlmKCB2YW5pdHlMaXN0Lmxlbmd0aCA+IDAgKXsgICAgICAgIFxyXG4gICAgICAgIGF3YWl0IHNhdmUobnVtYmVyLCB2YW5pdHlMaXN0LCBkZGIpO1xyXG4gICAgfSBcclxuXHJcbiAgICByZXR1cm4gdmFuaXR5TGlzdDtcclxuICBcclxufVxyXG5cclxuLyoqXHJcbiAqIEZ1bmN0aW9uIG5hbWU6IGNoZWNrRGF0YWJzZVxyXG4gKiBAcGFyYW0gbnVtYmVyIHN0cmluZ1xyXG4gKiBAcGFyYW0gZGRiIER5bmFtb0RCRG9jdW1lbnRDbGllbnRcclxuICogXHJcbiAqIEByZXR1cm4gUHJvbWlzZTxzdHJpbmdbXT5cclxuICogXHJcbiAqIEluc2lkZSB0aGUgZnVuY3Rpb246XHJcbiAqIDEuIE1ha2VzIGEgcmVxdWVzdCB0byB0aGUgZGF0YWJhc2UgZm9yIHRoZSBpbmNvbWluZyBwaG9uZSBudW1iZXJcclxuICogICAgdG8gc2VlIGlmIHRoZXJlIGlzIGEgcmVjb3JkIHN0b3JlZCBhbHJlYWR5XHJcbiAqIDIuIElmIHRoZXJlIGlzIGEgcmVjb3JkIGFscmVhZHkgc3RvcmVkLCByZXR1cm4gdGhlIHJlY29yZFxyXG4gKiAzLiBFbHNlLCByZXR1cm4gYW4gZW1wdHkgYXJyYXkgaW4gdGhlIHByb21pc2VcclxuICovXHJcbmNvbnN0IGNoZWNrRGF0YWJhc2UgPSBhc3luYyAobnVtYmVyOiBzdHJpbmcsIGRkYjogRHluYW1vREJEb2N1bWVudENsaWVudCk6IFByb21pc2U8c3RyaW5nW10+ID0+IFxyXG57ICAgXHJcbiAgICBjb25zdCBwYXJhbXMgPSB7XHJcbiAgICAgICAgVGFibGVOYW1lOiAndmFuaXR5X251bWJlcnMnLFxyXG4gICAgICAgIEtleToge1xyXG4gICAgICAgICAgICBwaG9uZV9udW1iZXI6IG51bWJlclxyXG4gICAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgbGV0IHJlc3VsdHM6IHN0cmluZ1tdID0gW107XHJcbiAgIFxyXG4gICAgdHJ5IHtcclxuICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBkZGIuc2VuZChuZXcgR2V0Q29tbWFuZChwYXJhbXMpKTtcclxuICAgICAgICBpZiggcmVzdWx0Lkl0ZW0/LnZhbml0eV9udW1iZXJzICE9IHVuZGVmaW5lZCApeyAgICAgICAgICAgIFxyXG4gICAgICAgICAgICByZXN1bHRzID0gcmVzdWx0Lkl0ZW0/LnZhbml0eV9udW1iZXJzO1xyXG4gICAgICAgIH1cclxuICAgIH0gY2F0Y2goZXJyKXsgICAgICAgIFxyXG4gICAgICAgIHRocm93IG5ldyBFcnJvcihcIkVuY291bnRlcmVkIGFuIGVycm9yIHdoaWxlIHRyeWluZyB0byByZXF1ZXN0IGV4aXN0aW5nIHJlY29yZHM6IFwiICsgZXJyKTtcclxuICAgIH0gXHJcblxyXG4gICAgcmV0dXJuIHJlc3VsdHM7XHJcbn1cclxuXHJcblxyXG4vKipcclxuICogRnVuY3Rpb24gbmFtZTogdmFuaXR5UGhvbmVOdW1iZXJIYW5kbGVyXHJcbiAqIEBwYXJhbSBldmVudCBDb25uZWN0Q29udGFjdEZsb3dFdmVudFxyXG4gKiBAcGFyYW0gY29udGV4dCBDb250ZXh0XHJcbiAqIEBwYXJhbSBjYWxsYmFjayBDb25uZWN0Q29udGFjdEZsb3dDYWxsYmFja1xyXG4gKiBcclxuICogQHJldHVybiBzdHJpbmdcclxuICogXHJcbiAqIEluc2lkZSB0aGUgZnVuY3Rpb246XHJcbiAqL1xyXG5leHBvcnQgY29uc3QgdmFuaXR5UGhvbmVOdW1iZXJIYW5kbGVyID0gYXN5bmMgKCBldmVudDogQ29ubmVjdENvbnRhY3RGbG93RXZlbnQsIGNvbnRleHQ6IENvbnRleHQsIGNhbGxiYWNrOiBDb25uZWN0Q29udGFjdEZsb3dDYWxsYmFjayApPT4ge1xyXG4gICAgQVdTLmNvbmZpZy51cGRhdGUoeyByZWdpb246IHByb2Nlc3MuZW52LkFXU19SRUdJT04gfSk7XHJcblxyXG4gICAgY29uc3QgZHluYW1vREIgPSBuZXcgRHluYW1vREJDbGllbnQoe30pO1xyXG4gICAgY29uc3QgZGRiID0gRHluYW1vREJEb2N1bWVudENsaWVudC5mcm9tKGR5bmFtb0RCKTtcclxuXHJcbiAgICB0cnkgeyBcclxuICAgICAgICBjb25zdCBwaG9uZU51bWJlciA9IGV2ZW50LkRldGFpbHM/LkNvbnRhY3REYXRhPy5DdXN0b21lckVuZHBvaW50Py5BZGRyZXNzO1xyXG4gICAgICAgIGlmKCBwaG9uZU51bWJlciA9PSB1bmRlZmluZWQpe1xyXG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ1VuYWJsZSB0byBnZXQgZXZlbnQgZGV0YWlscyBmcm9tIENvbm5lY3RDb250YWN0Rmxvd0V2ZW50Jyk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIFxyXG4gICAgICAgIGNvbnN0IHZhbGlkYXRlZE51bWJlciA9IHZhbGlkYXRlTnVtYmVyKHBob25lTnVtYmVyKTtcclxuXHJcbiAgICAgICAgY29uc3QgdmFuaXR5TGlzdCA9IGF3YWl0IGdlbmVyYXRlVmFuaXR5UGhvbmVOdW1iZXJzKHZhbGlkYXRlZE51bWJlciwgZGRiKTtcclxuXHJcbiAgICAgICAgY29uc3QgcmVzdWx0OiBDb25uZWN0Q29udGFjdEZsb3dSZXN1bHQgPSB7fTtcclxuXHJcbiAgICAgICAgaWYoIHZhbml0eUxpc3QubGVuZ3RoID4gMCApe1xyXG4gICAgICAgICAgICBjb25zdCBmaW5hbFZhbml0eUxpc3QgPSB2YW5pdHlMaXN0LnNsaWNlKC0zKTsgLy8gV2UncmUgb25seSByZXR1cm5pbmcgdGhlIGxhc3QgMyBtYXRjaGVzIHRvIHRoZSB1c2VyXHJcbiAgICAgICAgXHJcbiAgICAgICAgICAgIGZvciAoIGxldCBpID0gMDsgaSA8IGZpbmFsVmFuaXR5TGlzdC5sZW5ndGg7IGkrKyApe1xyXG4gICAgICAgICAgICAgICAgcmVzdWx0WydudW1iZXInICsgaV0gPSBmaW5hbFZhbml0eUxpc3RbaV0ucmVwbGFjZSgvKC4pL2csICckJiwgJyk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGxldCBzdGF0dXMgPSAnJztcclxuICAgICAgICBpZiggcmVzdWx0WydudW1iZXIwJ10gIT09ICd1bmRlZmluZWQnKXtcclxuICAgICAgICAgICAgc3RhdHVzID0gJ1N1Y2Nlc3MhJztcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBzdGF0dXMgPSAnTm8gbWF0Y2hlcyBmb3VuZC4nO1xyXG4gICAgICAgIH1cclxuICAgICAgICBjYWxsYmFjayhudWxsLCByZXN1bHQpOyAgICAgICAgICAgICAgICBcclxuICAgICAgICByZXR1cm4gc3RhdHVzO1xyXG4gICAgfSBjYXRjaCAoZXJyKXtcclxuICAgICAgICBjb25zdCBzdGF0dXMgPSAnRmFpbHVyZSEnOyAgICAgICAgXHJcbiAgICAgICAgY2FsbGJhY2soZXJyIGFzIEVycm9yKTtcclxuICAgICAgICByZXR1cm4gc3RhdHVzO1xyXG4gICAgfVxyXG59O1xyXG5cclxuIl19