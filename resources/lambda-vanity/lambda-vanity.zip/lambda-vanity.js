"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.vanityPhoneNumberHandler = void 0;
/*
This code retrieves the phone number from the associated contact flow
and attempts to derive the 5 "best"[1] vanity numbers from that phone number
and store the results a dynamoDB table tied to the original phone number

[1] "best" is determined to be the closest verbal representation of a number
    that does not contain offensive or slanderous words, this output can not
    be 100% guarenteed as new words are added to the offsensive list constantly
 */
const AWS = require("aws-sdk");
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const words = require('an-array-of-english-words');
/**
 * Function name: validateNumber
 * @param number string
 * @param dbClient DynamoDB.DocumentClient
 *
 * Inside the function:
 * 1. Validates that the number can be processed
 * 2. If it is not a number, or the number is empty, throws an error 'Phone number was null or undefined'
 * 3. If the number is not a valid number, throws an error 'Invalid phone number.'
 * 4. If the number passes validation, returns the output from processPhoneNumber()
 */
const validateNumber = (number) => {
    // Uses a standard expression to match valid, ten digit US phone numbers
    const validPhoneNumber = /^(\+1|1)?\d{10}$/;
    if (!number) {
        throw Error("Phone number was null or undefined");
    }
    if (!number.match(validPhoneNumber)) {
        throw Error("Invalid phone number");
    }
    return processPhoneNumber(number);
};
/**
 * Function name: processPhoneNumber
 * @param number string
 * @param
 * @returns
 */
const processPhoneNumber = (phoneNumber) => {
    // The regex to use to separate the country code from the rest of the phone number
    const phoneRegex = /^(\+1|1)?(\d{10})$/;
    // Returns only the last 10 digits of the phone number
    return phoneNumber.replace(phoneRegex, '$2');
};
/**
 * Function name: save
 * @param number string
 * @param ddb DynamoDBDocumentClient
 *
 * Inside the function:
 * 1. Set up the parameters to use to save the number to the dynamo database
 * 2. Saves the data to the database and returns the promise frm the transaction
 */
const save = async (phoneNumber, vanityList, ddb) => {
    // Build the parameters to make the request
    const params = {
        TableName: 'vanity_numbers',
        Item: {
            phone_number: phoneNumber,
            vanity_numbers: vanityList
        },
        ConditionExpresion: 'attribute_not_exists(phone_number)',
        ReturnConsumedCapacity: 'TOTAL'
    };
    await ddb.send(new lib_dynamodb_1.PutCommand(params));
};
/**
 * Function name: generateVanityPhoneNumbers
 * @param number string
 * @param ddb DynamoDBDocumentClient
 *
 * @return Promise<string[]>
 *
 * Inside the function:
 * 1. Checks the database to determine if a vanity list already exists
 * 2. If a vanity list exists, return that vanity list <= Returns out of the function
 * 3. If no vanity list exists, instantiate a new vanityList
 * 4. Split the phone number into the firstThree and lastSeven numbers (will use lastSeven to create vanity)
 * 5. Set up array map with keypad mappings
 * 6. Split the specific key mappings for each number into arrays
 * 7. Itterate over nested arrays to create string combinations based on the numbers received
 * 8. Add the first 5 permitations as 'throw away' permitations (i.e. will usually be something like 1111111)
 * 9. After the first 5, check if the number exists in the array of English
 *    words provided by the 'an-array-of-english-words' package, if it does,
 *    add it to the vanityList array
 * 10. Pull the last 5 matches from the vanityList
 * 11. Store those matches in the database
 * 12. Return the matches *
 */
const generateVanityPhoneNumbers = async (number, ddb) => {
    var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l;
    let vanityList = await checkDatabase(number, ddb);
    if (vanityList != undefined && vanityList.length > 0) {
        // The vanity list already exists in the database, so return it
        return vanityList;
    }
    vanityList = [];
    // Pulls the first three digits from the phone number
    const firstThree = number.slice(0, 3);
    // Pulls the last seven numbers from the phone number
    const lastSeven = number.slice(3).split('');
    const letterMap = new Map([
        ['0', '0'],
        ['1', '1'],
        ['2', 'ABC'],
        ['3', 'DEF'],
        ['4', 'GHI'],
        ['5', 'JKL'],
        ['6', 'MNO'],
        ['7', 'PQRS'],
        ['8', 'TUV'],
        ['9', 'WXYZ']
    ]);
    const spotOneStr = (_a = letterMap.get(lastSeven[0])) === null || _a === void 0 ? void 0 : _a.split('');
    const spotTwoStr = (_b = letterMap.get(lastSeven[1])) === null || _b === void 0 ? void 0 : _b.split('');
    const spotThreeStr = (_c = letterMap.get(lastSeven[2])) === null || _c === void 0 ? void 0 : _c.split('');
    const spotFourStr = (_d = letterMap.get(lastSeven[3])) === null || _d === void 0 ? void 0 : _d.split('');
    const spotFiveStr = (_e = letterMap.get(lastSeven[4])) === null || _e === void 0 ? void 0 : _e.split('');
    const spotSixStr = (_f = letterMap.get(lastSeven[5])) === null || _f === void 0 ? void 0 : _f.split('');
    const spotSevenStr = (_g = letterMap.get(lastSeven[6])) === null || _g === void 0 ? void 0 : _g.split('');
    // Check if any of the string arrays are empty, which means that the lastSeven didn't pick up all of the values
    if (spotOneStr == undefined || spotTwoStr == undefined || spotThreeStr == undefined || spotFourStr == undefined ||
        spotFiveStr == undefined || spotSixStr == undefined || spotSevenStr == undefined) {
        throw new Error("Unable to retrieve all number strings.");
    }
    // Loop through each groups of letters to create a combination string from each group of letters
    // At each iteration and sub iteration, we check to see if the list has been completed and if so
    //  break out to the previous level 
    for (let i = 0; i < spotOneStr.length; i++) {
        if (vanityList.length >= 5) {
            // list already contains the 5 words
            break;
        }
        for (let j = 0; j < spotTwoStr.length; j++) {
            if (vanityList.length >= 5) {
                // list already contains the 5 words
                break;
            }
            for (let k = 0; k < spotThreeStr.length; k++) {
                if (vanityList.length >= 5) {
                    // list already contains the 5 words
                    break;
                }
                for (let m = 0; m < spotFourStr.length; m++) {
                    if (vanityList.length >= 5) {
                        // list already contains the 5 words
                        break;
                    }
                    for (let n = 0; n < spotFiveStr.length; n++) {
                        if (vanityList.length >= 5) {
                            // list already contains the 5 words
                            break;
                        }
                        for (let p = 0; p < spotSixStr.length; p++) {
                            if (vanityList.length >= 5) {
                                // list already contains the 5 words
                                break;
                            }
                            for (let q = 0; q < spotSevenStr.length; q++) {
                                if (vanityList.length >= 5) {
                                    // list already contains the 5 words
                                    break;
                                }
                                const phoneWord = spotOneStr[i] + spotTwoStr[j] + spotThreeStr[k] + spotFourStr[m] + spotFiveStr[n] + spotSixStr[p] + spotSevenStr[q];
                                const vanityNumber = firstThree + phoneWord;
                                if (words.includes(phoneWord.toLowerCase())) {
                                    // If the combinations of letters from the 7 characters forms a word, add it to the list
                                    vanityList.push(vanityNumber);
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    // If there were no combinations found using the full seven digit string,
    // We'll attempt a search based on just the last four instead
    if (vanityList.length == 0) { // The default list length of nonsense combinations is 7                
        // Pulls the first six digits from the phone number
        const firstSix = number.slice(0, 6);
        // Pulls only the last four digits from the phone number
        const lastFour = number.slice(6).split('');
        const retrySpotOneStr = (_h = letterMap.get(lastFour[0])) === null || _h === void 0 ? void 0 : _h.split('');
        const retrySpotTwoStr = (_j = letterMap.get(lastFour[1])) === null || _j === void 0 ? void 0 : _j.split('');
        const retrySpotThreeStr = (_k = letterMap.get(lastFour[2])) === null || _k === void 0 ? void 0 : _k.split('');
        const retrySpotFourStr = (_l = letterMap.get(lastFour[3])) === null || _l === void 0 ? void 0 : _l.split('');
        // Check if any of the string arrays are empty, which means that the lastSeven didn't pick up all of the values
        if (retrySpotOneStr == undefined || retrySpotTwoStr == undefined || retrySpotThreeStr == undefined || retrySpotFourStr == undefined) {
            throw new Error("Unable to retrieve all number strings.");
        }
        // Loop through each combination of digits to attempt to find words
        for (let i = 0; i < retrySpotOneStr.length; i++) {
            // If the vanity list is full, we'll stop the loop
            if (vanityList.length >= 5) {
                break;
            }
            for (let j = 0; j < retrySpotTwoStr.length; j++) {
                // If the vanity list is full, we'll stop the loop
                if (vanityList.length >= 5) {
                    break;
                }
                for (let k = 0; k < retrySpotThreeStr.length; k++) {
                    // If the vanity list is full, we'll stop the loop
                    if (vanityList.length >= 5) {
                        break;
                    }
                    for (let m = 0; m < retrySpotFourStr.length; m++) {
                        // If the vanity list is full, we'll stop the loop
                        if (vanityList.length >= 5) {
                            break;
                        }
                        const phoneWord = retrySpotOneStr[i] + retrySpotTwoStr[j] + retrySpotThreeStr[k] + retrySpotFourStr[m];
                        const vanityNumber = firstSix + phoneWord;
                        // If the vanity word created by the last four digits is in the words list, add it to the vanity list
                        if (words.includes(phoneWord)) {
                            vanityList.push(vanityNumber);
                        }
                    }
                }
            }
        }
    }
    if (vanityList.length > 0) {
        console.log('Generated vanity numbers! Saving to db: ' + vanityList);
        await save(number, vanityList, ddb);
    }
    else {
        vanityList.push("We're sorry, there were no vanity numbers that matched your phone number.");
    }
    return vanityList;
};
/**
 * Function name: checkDatabse
 * @param number string
 * @param ddb DynamoDBDocumentClient
 *
 * @return Promise<string[]>
 *
 * Inside the function:
 * 1. Makes a request to the database for the incoming phone number
 *    to see if there is a record stored already
 * 2. If there is a record already stored, return the record
 * 3. Else, return an empty array in the promise
 */
const checkDatabase = async (number, ddb) => {
    var _a, _b;
    const params = {
        TableName: 'vanity_numbers',
        Key: {
            phone_number: number
        }
    };
    let results = [];
    try {
        const result = await ddb.send(new lib_dynamodb_1.GetCommand(params));
        if (((_a = result.Item) === null || _a === void 0 ? void 0 : _a.vanity_numbers) != undefined) {
            console.log('Found vanity numbers in db: ' + result.Item.vanity_numbers);
            results = (_b = result.Item) === null || _b === void 0 ? void 0 : _b.vanity_numbers;
        }
    }
    catch (err) {
        console.error(err);
        throw new Error("Encountered an error while trying to request existing records: " + err);
    }
    return results;
};
/**
 * Function name: vanityPhoneNumberHandler
 * @param event ConnectContactFlowEvent
 * @param context Context
 *
 * @return string
 *
 * Inside the function:
 */
exports.vanityPhoneNumberHandler = async (event, context, callback) => {
    var _a, _b, _c;
    AWS.config.update({ region: process.env.AWS_REGION });
    const dynamoDB = new client_dynamodb_1.DynamoDBClient({});
    const ddb = lib_dynamodb_1.DynamoDBDocumentClient.from(dynamoDB);
    try {
        const phoneNumber = (_c = (_b = (_a = event.Details) === null || _a === void 0 ? void 0 : _a.ContactData) === null || _b === void 0 ? void 0 : _b.CustomerEndpoint) === null || _c === void 0 ? void 0 : _c.Address;
        if (phoneNumber == undefined) {
            throw new Error('Unable to get event details from ConnectContactFlowEvent');
        }
        const validatedNumber = validateNumber(phoneNumber);
        const vanityList = await generateVanityPhoneNumbers(validatedNumber, ddb);
        const result = {};
        const finalVanityList = vanityList.slice(-3); // We're only returning the last 5 matches to the user
        for (let i = 0; i < finalVanityList.length; i++) {
            result['number' + i] = finalVanityList[i].replace(/(.)/g, '$&, ');
        }
        let status = '';
        if (result['number0'] !== 'undefined') {
            status = 'Success!';
        }
        else {
            status = 'No matches found.';
        }
        callback(null, result);
        console.log(status);
        return status;
    }
    catch (err) {
        const status = 'Failure!';
        console.log(status);
        console.log(err);
        callback(err);
        return status;
    }
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibGFtYmRhLXZhbml0eS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImxhbWJkYS12YW5pdHkudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUE7Ozs7Ozs7O0dBUUc7QUFDSCwrQkFBK0I7QUFDL0IsOERBQTBEO0FBQzFELHdEQUF1RjtBQUd2RixNQUFNLEtBQUssR0FBWSxPQUFPLENBQUMsMkJBQTJCLENBQUMsQ0FBQztBQUU1RDs7Ozs7Ozs7OztHQVVHO0FBQ0gsTUFBTSxjQUFjLEdBQUcsQ0FBQyxNQUFjLEVBQVUsRUFBRTtJQUM5Qyx3RUFBd0U7SUFDeEUsTUFBTSxnQkFBZ0IsR0FBRyxrQkFBa0IsQ0FBQztJQUU1QyxJQUFJLENBQUMsTUFBTSxFQUFFO1FBQ1QsTUFBTSxLQUFLLENBQUMsb0NBQW9DLENBQUMsQ0FBQztLQUNyRDtJQUVELElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLGdCQUFnQixDQUFDLEVBQUU7UUFDakMsTUFBTSxLQUFLLENBQUMsc0JBQXNCLENBQUMsQ0FBQztLQUN2QztJQUVELE9BQU8sa0JBQWtCLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDdEMsQ0FBQyxDQUFBO0FBRUQ7Ozs7O0dBS0c7QUFDSCxNQUFNLGtCQUFrQixHQUFHLENBQUMsV0FBbUIsRUFBVSxFQUFFO0lBQ3ZELGtGQUFrRjtJQUNsRixNQUFNLFVBQVUsR0FBRyxvQkFBb0IsQ0FBQztJQUV4QyxzREFBc0Q7SUFDdEQsT0FBTyxXQUFXLENBQUMsT0FBTyxDQUFFLFVBQVUsRUFBRSxJQUFJLENBQUUsQ0FBQztBQUNuRCxDQUFDLENBQUE7QUFFRDs7Ozs7Ozs7R0FRRztBQUNILE1BQU0sSUFBSSxHQUFHLEtBQUssRUFBRSxXQUFtQixFQUFFLFVBQW9CLEVBQUUsR0FBMkIsRUFBRyxFQUFFO0lBRTNGLDJDQUEyQztJQUMzQyxNQUFNLE1BQU0sR0FBUTtRQUNoQixTQUFTLEVBQUUsZ0JBQWdCO1FBQzNCLElBQUksRUFBRTtZQUNGLFlBQVksRUFBRSxXQUFXO1lBQ3pCLGNBQWMsRUFBRSxVQUFVO1NBQzdCO1FBQ0Qsa0JBQWtCLEVBQUUsb0NBQW9DO1FBQ3hELHNCQUFzQixFQUFFLE9BQU87S0FDbEMsQ0FBQztJQUVGLE1BQU0sR0FBRyxDQUFDLElBQUksQ0FDVixJQUFJLHlCQUFVLENBQUMsTUFBTSxDQUFDLENBQ3pCLENBQUE7QUFDTCxDQUFDLENBQUE7QUFFRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztHQXNCRztBQUNILE1BQU0sMEJBQTBCLEdBQUcsS0FBSyxFQUFFLE1BQWMsRUFBRSxHQUEyQixFQUFxQixFQUFFOztJQUN4RyxJQUFJLFVBQVUsR0FBYSxNQUFNLGFBQWEsQ0FBQyxNQUFNLEVBQUUsR0FBRyxDQUFDLENBQUM7SUFFNUQsSUFBRyxVQUFVLElBQUksU0FBUyxJQUFJLFVBQVUsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFDO1FBQ2hELCtEQUErRDtRQUMvRCxPQUFPLFVBQVUsQ0FBQztLQUNyQjtJQUVELFVBQVUsR0FBRyxFQUFFLENBQUM7SUFFaEIscURBQXFEO0lBQ3JELE1BQU0sVUFBVSxHQUFHLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ3JDLHFEQUFxRDtJQUNyRCxNQUFNLFNBQVMsR0FBRyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQztJQUU1QyxNQUFNLFNBQVMsR0FBRyxJQUFJLEdBQUcsQ0FBQztRQUN0QixDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUM7UUFDVixDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUM7UUFDVixDQUFDLEdBQUcsRUFBRSxLQUFLLENBQUM7UUFDWixDQUFDLEdBQUcsRUFBRSxLQUFLLENBQUM7UUFDWixDQUFDLEdBQUcsRUFBRSxLQUFLLENBQUM7UUFDWixDQUFDLEdBQUcsRUFBRSxLQUFLLENBQUM7UUFDWixDQUFDLEdBQUcsRUFBRSxLQUFLLENBQUM7UUFDWixDQUFDLEdBQUcsRUFBRSxNQUFNLENBQUM7UUFDYixDQUFDLEdBQUcsRUFBRSxLQUFLLENBQUM7UUFDWixDQUFDLEdBQUcsRUFBRSxNQUFNLENBQUM7S0FDaEIsQ0FBQyxDQUFDO0lBRUgsTUFBTSxVQUFVLFNBQUcsU0FBUyxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsMENBQUUsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFFO0lBQzNELE1BQU0sVUFBVSxTQUFHLFNBQVMsQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLDBDQUFFLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQztJQUMxRCxNQUFNLFlBQVksU0FBRyxTQUFTLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQywwQ0FBRSxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUM7SUFDNUQsTUFBTSxXQUFXLFNBQUcsU0FBUyxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsMENBQUUsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDO0lBQzNELE1BQU0sV0FBVyxTQUFHLFNBQVMsQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLDBDQUFFLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQztJQUMzRCxNQUFNLFVBQVUsU0FBRyxTQUFTLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQywwQ0FBRSxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUM7SUFDMUQsTUFBTSxZQUFZLFNBQUcsU0FBUyxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsMENBQUUsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDO0lBRTVELCtHQUErRztJQUMvRyxJQUFJLFVBQVUsSUFBSSxTQUFTLElBQUksVUFBVSxJQUFJLFNBQVMsSUFBSSxZQUFZLElBQUksU0FBUyxJQUFJLFdBQVcsSUFBSSxTQUFTO1FBQzNHLFdBQVcsSUFBSSxTQUFTLElBQUksVUFBVSxJQUFJLFNBQVMsSUFBSSxZQUFZLElBQUksU0FBUyxFQUFFO1FBQzlFLE1BQU0sSUFBSSxLQUFLLENBQUMsd0NBQXdDLENBQUMsQ0FBQztLQUM3RDtJQUVMLGdHQUFnRztJQUNoRyxnR0FBZ0c7SUFDaEcsb0NBQW9DO0lBQ3BDLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxVQUFVLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1FBQ3hDLElBQUksVUFBVSxDQUFDLE1BQU0sSUFBSSxDQUFDLEVBQUU7WUFDeEIsb0NBQW9DO1lBQ3BDLE1BQU07U0FDVDtRQUVELEtBQU0sSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxVQUFVLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQ3pDLElBQUksVUFBVSxDQUFDLE1BQU0sSUFBSSxDQUFDLEVBQUU7Z0JBQ3hCLG9DQUFvQztnQkFDcEMsTUFBTTthQUNUO1lBRUQsS0FBTSxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFlBQVksQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7Z0JBQzNDLElBQUksVUFBVSxDQUFDLE1BQU0sSUFBSSxDQUFDLEVBQUU7b0JBQ3hCLG9DQUFvQztvQkFDcEMsTUFBTTtpQkFDVDtnQkFFRCxLQUFNLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsV0FBVyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtvQkFDMUMsSUFBSSxVQUFVLENBQUMsTUFBTSxJQUFJLENBQUMsRUFBRTt3QkFDeEIsb0NBQW9DO3dCQUNwQyxNQUFNO3FCQUNUO29CQUVELEtBQU0sSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxXQUFXLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO3dCQUMxQyxJQUFJLFVBQVUsQ0FBQyxNQUFNLElBQUksQ0FBQyxFQUFFOzRCQUN4QixvQ0FBb0M7NEJBQ3BDLE1BQU07eUJBQ1Q7d0JBRUQsS0FBTSxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFVBQVUsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7NEJBQ3pDLElBQUksVUFBVSxDQUFDLE1BQU0sSUFBSSxDQUFDLEVBQUU7Z0NBQ3hCLG9DQUFvQztnQ0FDcEMsTUFBTTs2QkFDVDs0QkFFRCxLQUFNLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsWUFBWSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtnQ0FDM0MsSUFBSSxVQUFVLENBQUMsTUFBTSxJQUFJLENBQUMsRUFBRTtvQ0FDeEIsb0NBQW9DO29DQUNwQyxNQUFNO2lDQUNUO2dDQUVELE1BQU0sU0FBUyxHQUFHLFVBQVUsQ0FBQyxDQUFDLENBQUMsR0FBRyxVQUFVLENBQUMsQ0FBQyxDQUFDLEdBQUcsWUFBWSxDQUFDLENBQUMsQ0FBQyxHQUFHLFdBQVcsQ0FBQyxDQUFDLENBQUMsR0FBRyxXQUFXLENBQUMsQ0FBQyxDQUFDLEdBQUcsVUFBVSxDQUFDLENBQUMsQ0FBQyxHQUFHLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQztnQ0FDdEksTUFBTSxZQUFZLEdBQUcsVUFBVSxHQUFHLFNBQVMsQ0FBQztnQ0FDNUMsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxXQUFXLEVBQUUsQ0FBRSxFQUFFO29DQUMxQyx3RkFBd0Y7b0NBQ3hGLFVBQVUsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUM7aUNBQ2pDOzZCQUNKO3lCQUNKO3FCQUNKO2lCQUNKO2FBQ0o7U0FDSjtLQUNKO0lBRUQseUVBQXlFO0lBQ3pFLDZEQUE2RDtJQUM3RCxJQUFJLFVBQVUsQ0FBQyxNQUFNLElBQUksQ0FBQyxFQUFHLEVBQUUsd0VBQXdFO1FBRW5HLG1EQUFtRDtRQUNuRCxNQUFNLFFBQVEsR0FBRyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQztRQUNuQyx3REFBd0Q7UUFDeEQsTUFBTSxRQUFRLEdBQUcsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUM7UUFFM0MsTUFBTSxlQUFlLFNBQUcsU0FBUyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsMENBQUUsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFFO1FBQy9ELE1BQU0sZUFBZSxTQUFHLFNBQVMsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLDBDQUFFLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUM5RCxNQUFNLGlCQUFpQixTQUFHLFNBQVMsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLDBDQUFFLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUNoRSxNQUFNLGdCQUFnQixTQUFHLFNBQVMsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLDBDQUFFLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUUvRCwrR0FBK0c7UUFDL0csSUFBSSxlQUFlLElBQUksU0FBUyxJQUFJLGVBQWUsSUFBSSxTQUFTLElBQUksaUJBQWlCLElBQUksU0FBUyxJQUFJLGdCQUFnQixJQUFJLFNBQVMsRUFBRTtZQUNqSSxNQUFNLElBQUksS0FBSyxDQUFDLHdDQUF3QyxDQUFDLENBQUM7U0FDN0Q7UUFFRCxtRUFBbUU7UUFDbkUsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLGVBQWUsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDN0Msa0RBQWtEO1lBQ2xELElBQUksVUFBVSxDQUFDLE1BQU0sSUFBSSxDQUFDLEVBQUU7Z0JBQ3hCLE1BQU07YUFDVDtZQUVELEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxlQUFlLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO2dCQUM3QyxrREFBa0Q7Z0JBQ2xELElBQUksVUFBVSxDQUFDLE1BQU0sSUFBSSxDQUFDLEVBQUU7b0JBQ3hCLE1BQU07aUJBQ1Q7Z0JBRUQsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLGlCQUFpQixDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtvQkFDL0Msa0RBQWtEO29CQUNsRCxJQUFJLFVBQVUsQ0FBQyxNQUFNLElBQUksQ0FBQyxFQUFFO3dCQUN4QixNQUFNO3FCQUNUO29CQUVELEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxnQkFBZ0IsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7d0JBQzlDLGtEQUFrRDt3QkFDbEQsSUFBSSxVQUFVLENBQUMsTUFBTSxJQUFJLENBQUMsRUFBRTs0QkFDeEIsTUFBTTt5QkFDVDt3QkFDRCxNQUFNLFNBQVMsR0FBRyxlQUFlLENBQUMsQ0FBQyxDQUFDLEdBQUcsZUFBZSxDQUFDLENBQUMsQ0FBQyxHQUFHLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxHQUFHLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUN2RyxNQUFNLFlBQVksR0FBRyxRQUFRLEdBQUcsU0FBUyxDQUFDO3dCQUMxQyxxR0FBcUc7d0JBQ3JHLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsRUFBRTs0QkFDM0IsVUFBVSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQzt5QkFDakM7cUJBRUo7aUJBQ0o7YUFDSjtTQUNKO0tBQ0o7SUFFRCxJQUFJLFVBQVUsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO1FBQ3ZCLE9BQU8sQ0FBQyxHQUFHLENBQUMsMENBQTBDLEdBQUcsVUFBVSxDQUFDLENBQUM7UUFDckUsTUFBTSxJQUFJLENBQUMsTUFBTSxFQUFFLFVBQVUsRUFBRSxHQUFHLENBQUMsQ0FBQztLQUN2QztTQUFNO1FBQ0gsVUFBVSxDQUFDLElBQUksQ0FBQywyRUFBMkUsQ0FBQyxDQUFBO0tBQy9GO0lBRUQsT0FBTyxVQUFVLENBQUM7QUFFdEIsQ0FBQyxDQUFBO0FBRUQ7Ozs7Ozs7Ozs7OztHQVlHO0FBQ0gsTUFBTSxhQUFhLEdBQUcsS0FBSyxFQUFFLE1BQWMsRUFBRSxHQUEyQixFQUFxQixFQUFFOztJQUUzRixNQUFNLE1BQU0sR0FBRztRQUNYLFNBQVMsRUFBRSxnQkFBZ0I7UUFDM0IsR0FBRyxFQUFFO1lBQ0QsWUFBWSxFQUFFLE1BQU07U0FDdkI7S0FDSixDQUFDO0lBRUYsSUFBSSxPQUFPLEdBQWEsRUFBRSxDQUFDO0lBRTNCLElBQUk7UUFDQSxNQUFNLE1BQU0sR0FBRyxNQUFNLEdBQUcsQ0FBQyxJQUFJLENBQUMsSUFBSSx5QkFBVSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7UUFDdEQsSUFBSSxPQUFBLE1BQU0sQ0FBQyxJQUFJLDBDQUFFLGNBQWMsS0FBSSxTQUFTLEVBQUU7WUFDMUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyw4QkFBOEIsR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDO1lBQ3pFLE9BQU8sU0FBRyxNQUFNLENBQUMsSUFBSSwwQ0FBRSxjQUFjLENBQUM7U0FDekM7S0FDSjtJQUFDLE9BQU0sR0FBRyxFQUFDO1FBQ1IsT0FBTyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUNuQixNQUFNLElBQUksS0FBSyxDQUFDLGlFQUFpRSxHQUFHLEdBQUcsQ0FBQyxDQUFDO0tBQzVGO0lBRUQsT0FBTyxPQUFPLENBQUM7QUFDbkIsQ0FBQyxDQUFBO0FBR0Q7Ozs7Ozs7O0dBUUc7QUFDVSxRQUFBLHdCQUF3QixHQUFHLEtBQUssRUFBRyxLQUE4QixFQUFFLE9BQWdCLEVBQUUsUUFBb0MsRUFBRSxFQUFFOztJQUN0SSxHQUFHLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLE1BQU0sRUFBRSxPQUFPLENBQUMsR0FBRyxDQUFDLFVBQVUsRUFBRSxDQUFDLENBQUM7SUFFdEQsTUFBTSxRQUFRLEdBQUcsSUFBSSxnQ0FBYyxDQUFDLEVBQUUsQ0FBQyxDQUFDO0lBQ3hDLE1BQU0sR0FBRyxHQUFHLHFDQUFzQixDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztJQUVsRCxJQUFJO1FBQ0EsTUFBTSxXQUFXLHFCQUFHLEtBQUssQ0FBQyxPQUFPLDBDQUFFLFdBQVcsMENBQUUsZ0JBQWdCLDBDQUFFLE9BQU8sQ0FBQztRQUMxRSxJQUFJLFdBQVcsSUFBSSxTQUFTLEVBQUM7WUFDekIsTUFBTSxJQUFJLEtBQUssQ0FBQywwREFBMEQsQ0FBQyxDQUFDO1NBQy9FO1FBRUQsTUFBTSxlQUFlLEdBQUcsY0FBYyxDQUFDLFdBQVcsQ0FBQyxDQUFDO1FBRXBELE1BQU0sVUFBVSxHQUFHLE1BQU0sMEJBQTBCLENBQUMsZUFBZSxFQUFFLEdBQUcsQ0FBQyxDQUFDO1FBRTFFLE1BQU0sTUFBTSxHQUE2QixFQUFFLENBQUM7UUFFNUMsTUFBTSxlQUFlLEdBQUcsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsc0RBQXNEO1FBRXBHLEtBQU0sSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxlQUFlLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQzlDLE1BQU0sQ0FBQyxRQUFRLEdBQUcsQ0FBQyxDQUFDLEdBQUcsZUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsTUFBTSxDQUFDLENBQUM7U0FDckU7UUFFRCxJQUFJLE1BQU0sR0FBRyxFQUFFLENBQUM7UUFDaEIsSUFBSSxNQUFNLENBQUMsU0FBUyxDQUFDLEtBQUssV0FBVyxFQUFDO1lBQ2xDLE1BQU0sR0FBRyxVQUFVLENBQUM7U0FDdkI7YUFBTTtZQUNILE1BQU0sR0FBRyxtQkFBbUIsQ0FBQztTQUNoQztRQUNELFFBQVEsQ0FBQyxJQUFJLEVBQUUsTUFBTSxDQUFDLENBQUM7UUFDdkIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUNwQixPQUFPLE1BQU0sQ0FBQztLQUNqQjtJQUFDLE9BQU8sR0FBRyxFQUFDO1FBQ1QsTUFBTSxNQUFNLEdBQUcsVUFBVSxDQUFDO1FBQzFCLE9BQU8sQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDcEIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUNqQixRQUFRLENBQUMsR0FBWSxDQUFDLENBQUM7UUFDdkIsT0FBTyxNQUFNLENBQUM7S0FDakI7QUFDTCxDQUFDLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyIvKlxyXG5UaGlzIGNvZGUgcmV0cmlldmVzIHRoZSBwaG9uZSBudW1iZXIgZnJvbSB0aGUgYXNzb2NpYXRlZCBjb250YWN0IGZsb3dcclxuYW5kIGF0dGVtcHRzIHRvIGRlcml2ZSB0aGUgNSBcImJlc3RcIlsxXSB2YW5pdHkgbnVtYmVycyBmcm9tIHRoYXQgcGhvbmUgbnVtYmVyXHJcbmFuZCBzdG9yZSB0aGUgcmVzdWx0cyBhIGR5bmFtb0RCIHRhYmxlIHRpZWQgdG8gdGhlIG9yaWdpbmFsIHBob25lIG51bWJlclxyXG5cclxuWzFdIFwiYmVzdFwiIGlzIGRldGVybWluZWQgdG8gYmUgdGhlIGNsb3Nlc3QgdmVyYmFsIHJlcHJlc2VudGF0aW9uIG9mIGEgbnVtYmVyXHJcbiAgICB0aGF0IGRvZXMgbm90IGNvbnRhaW4gb2ZmZW5zaXZlIG9yIHNsYW5kZXJvdXMgd29yZHMsIHRoaXMgb3V0cHV0IGNhbiBub3RcclxuICAgIGJlIDEwMCUgZ3VhcmVudGVlZCBhcyBuZXcgd29yZHMgYXJlIGFkZGVkIHRvIHRoZSBvZmZzZW5zaXZlIGxpc3QgY29uc3RhbnRseVxyXG4gKi9cclxuaW1wb3J0ICogYXMgQVdTIGZyb20gJ2F3cy1zZGsnO1xyXG5pbXBvcnQgeyBEeW5hbW9EQkNsaWVudCB9IGZyb20gJ0Bhd3Mtc2RrL2NsaWVudC1keW5hbW9kYic7XHJcbmltcG9ydCB7IER5bmFtb0RCRG9jdW1lbnRDbGllbnQsIFB1dENvbW1hbmQsIEdldENvbW1hbmQgfSBmcm9tICdAYXdzLXNkay9saWItZHluYW1vZGInO1xyXG5pbXBvcnQgeyBDb25uZWN0Q29udGFjdEZsb3dDYWxsYmFjaywgQ29ubmVjdENvbnRhY3RGbG93RXZlbnQsIENvbm5lY3RDb250YWN0Rmxvd1Jlc3VsdCwgQ29udGV4dCB9IGZyb20gJ2F3cy1sYW1iZGEnO1xyXG5cclxuY29uc3Qgd29yZHM6c3RyaW5nW10gPSByZXF1aXJlKCdhbi1hcnJheS1vZi1lbmdsaXNoLXdvcmRzJyk7XHJcblxyXG4vKipcclxuICogRnVuY3Rpb24gbmFtZTogdmFsaWRhdGVOdW1iZXJcclxuICogQHBhcmFtIG51bWJlciBzdHJpbmdcclxuICogQHBhcmFtIGRiQ2xpZW50IER5bmFtb0RCLkRvY3VtZW50Q2xpZW50XHJcbiAqIFxyXG4gKiBJbnNpZGUgdGhlIGZ1bmN0aW9uOlxyXG4gKiAxLiBWYWxpZGF0ZXMgdGhhdCB0aGUgbnVtYmVyIGNhbiBiZSBwcm9jZXNzZWRcclxuICogMi4gSWYgaXQgaXMgbm90IGEgbnVtYmVyLCBvciB0aGUgbnVtYmVyIGlzIGVtcHR5LCB0aHJvd3MgYW4gZXJyb3IgJ1Bob25lIG51bWJlciB3YXMgbnVsbCBvciB1bmRlZmluZWQnXHJcbiAqIDMuIElmIHRoZSBudW1iZXIgaXMgbm90IGEgdmFsaWQgbnVtYmVyLCB0aHJvd3MgYW4gZXJyb3IgJ0ludmFsaWQgcGhvbmUgbnVtYmVyLidcclxuICogNC4gSWYgdGhlIG51bWJlciBwYXNzZXMgdmFsaWRhdGlvbiwgcmV0dXJucyB0aGUgb3V0cHV0IGZyb20gcHJvY2Vzc1Bob25lTnVtYmVyKClcclxuICovXHJcbmNvbnN0IHZhbGlkYXRlTnVtYmVyID0gKG51bWJlcjogc3RyaW5nKTogc3RyaW5nID0+IHtcclxuICAgIC8vIFVzZXMgYSBzdGFuZGFyZCBleHByZXNzaW9uIHRvIG1hdGNoIHZhbGlkLCB0ZW4gZGlnaXQgVVMgcGhvbmUgbnVtYmVyc1xyXG4gICAgY29uc3QgdmFsaWRQaG9uZU51bWJlciA9IC9eKFxcKzF8MSk/XFxkezEwfSQvO1xyXG5cclxuICAgIGlmKCAhbnVtYmVyICl7XHJcbiAgICAgICAgdGhyb3cgRXJyb3IoXCJQaG9uZSBudW1iZXIgd2FzIG51bGwgb3IgdW5kZWZpbmVkXCIpOyAgICBcclxuICAgIH1cclxuXHJcbiAgICBpZiggIW51bWJlci5tYXRjaCh2YWxpZFBob25lTnVtYmVyKSApe1xyXG4gICAgICAgIHRocm93IEVycm9yKFwiSW52YWxpZCBwaG9uZSBudW1iZXJcIik7XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIHByb2Nlc3NQaG9uZU51bWJlcihudW1iZXIpO1xyXG59XHJcblxyXG4vKipcclxuICogRnVuY3Rpb24gbmFtZTogcHJvY2Vzc1Bob25lTnVtYmVyXHJcbiAqIEBwYXJhbSBudW1iZXIgc3RyaW5nXHJcbiAqIEBwYXJhbSBcclxuICogQHJldHVybnMgXHJcbiAqL1xyXG5jb25zdCBwcm9jZXNzUGhvbmVOdW1iZXIgPSAocGhvbmVOdW1iZXI6IHN0cmluZyk6IHN0cmluZyA9PiB7XHJcbiAgICAvLyBUaGUgcmVnZXggdG8gdXNlIHRvIHNlcGFyYXRlIHRoZSBjb3VudHJ5IGNvZGUgZnJvbSB0aGUgcmVzdCBvZiB0aGUgcGhvbmUgbnVtYmVyXHJcbiAgICBjb25zdCBwaG9uZVJlZ2V4ID0gL14oXFwrMXwxKT8oXFxkezEwfSkkLztcclxuXHJcbiAgICAvLyBSZXR1cm5zIG9ubHkgdGhlIGxhc3QgMTAgZGlnaXRzIG9mIHRoZSBwaG9uZSBudW1iZXJcclxuICAgIHJldHVybiBwaG9uZU51bWJlci5yZXBsYWNlKCBwaG9uZVJlZ2V4LCAnJDInICk7XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBGdW5jdGlvbiBuYW1lOiBzYXZlXHJcbiAqIEBwYXJhbSBudW1iZXIgc3RyaW5nXHJcbiAqIEBwYXJhbSBkZGIgRHluYW1vREJEb2N1bWVudENsaWVudFxyXG4gKiBcclxuICogSW5zaWRlIHRoZSBmdW5jdGlvbjpcclxuICogMS4gU2V0IHVwIHRoZSBwYXJhbWV0ZXJzIHRvIHVzZSB0byBzYXZlIHRoZSBudW1iZXIgdG8gdGhlIGR5bmFtbyBkYXRhYmFzZVxyXG4gKiAyLiBTYXZlcyB0aGUgZGF0YSB0byB0aGUgZGF0YWJhc2UgYW5kIHJldHVybnMgdGhlIHByb21pc2UgZnJtIHRoZSB0cmFuc2FjdGlvblxyXG4gKi9cclxuY29uc3Qgc2F2ZSA9IGFzeW5jIChwaG9uZU51bWJlcjogc3RyaW5nLCB2YW5pdHlMaXN0OiBzdHJpbmdbXSwgZGRiOiBEeW5hbW9EQkRvY3VtZW50Q2xpZW50ICkgPT4ge1xyXG5cclxuICAgIC8vIEJ1aWxkIHRoZSBwYXJhbWV0ZXJzIHRvIG1ha2UgdGhlIHJlcXVlc3RcclxuICAgIGNvbnN0IHBhcmFtczogYW55ID0ge1xyXG4gICAgICAgIFRhYmxlTmFtZTogJ3Zhbml0eV9udW1iZXJzJyxcclxuICAgICAgICBJdGVtOiB7XHJcbiAgICAgICAgICAgIHBob25lX251bWJlcjogcGhvbmVOdW1iZXIsXHJcbiAgICAgICAgICAgIHZhbml0eV9udW1iZXJzOiB2YW5pdHlMaXN0XHJcbiAgICAgICAgfSxcclxuICAgICAgICBDb25kaXRpb25FeHByZXNpb246ICdhdHRyaWJ1dGVfbm90X2V4aXN0cyhwaG9uZV9udW1iZXIpJyxcclxuICAgICAgICBSZXR1cm5Db25zdW1lZENhcGFjaXR5OiAnVE9UQUwnXHJcbiAgICB9O1xyXG5cclxuICAgIGF3YWl0IGRkYi5zZW5kKFxyXG4gICAgICAgIG5ldyBQdXRDb21tYW5kKHBhcmFtcylcclxuICAgIClcclxufVxyXG5cclxuLyoqXHJcbiAqIEZ1bmN0aW9uIG5hbWU6IGdlbmVyYXRlVmFuaXR5UGhvbmVOdW1iZXJzXHJcbiAqIEBwYXJhbSBudW1iZXIgc3RyaW5nXHJcbiAqIEBwYXJhbSBkZGIgRHluYW1vREJEb2N1bWVudENsaWVudFxyXG4gKiBcclxuICogQHJldHVybiBQcm9taXNlPHN0cmluZ1tdPlxyXG4gKiBcclxuICogSW5zaWRlIHRoZSBmdW5jdGlvbjpcclxuICogMS4gQ2hlY2tzIHRoZSBkYXRhYmFzZSB0byBkZXRlcm1pbmUgaWYgYSB2YW5pdHkgbGlzdCBhbHJlYWR5IGV4aXN0c1xyXG4gKiAyLiBJZiBhIHZhbml0eSBsaXN0IGV4aXN0cywgcmV0dXJuIHRoYXQgdmFuaXR5IGxpc3QgPD0gUmV0dXJucyBvdXQgb2YgdGhlIGZ1bmN0aW9uXHJcbiAqIDMuIElmIG5vIHZhbml0eSBsaXN0IGV4aXN0cywgaW5zdGFudGlhdGUgYSBuZXcgdmFuaXR5TGlzdCBcclxuICogNC4gU3BsaXQgdGhlIHBob25lIG51bWJlciBpbnRvIHRoZSBmaXJzdFRocmVlIGFuZCBsYXN0U2V2ZW4gbnVtYmVycyAod2lsbCB1c2UgbGFzdFNldmVuIHRvIGNyZWF0ZSB2YW5pdHkpXHJcbiAqIDUuIFNldCB1cCBhcnJheSBtYXAgd2l0aCBrZXlwYWQgbWFwcGluZ3NcclxuICogNi4gU3BsaXQgdGhlIHNwZWNpZmljIGtleSBtYXBwaW5ncyBmb3IgZWFjaCBudW1iZXIgaW50byBhcnJheXNcclxuICogNy4gSXR0ZXJhdGUgb3ZlciBuZXN0ZWQgYXJyYXlzIHRvIGNyZWF0ZSBzdHJpbmcgY29tYmluYXRpb25zIGJhc2VkIG9uIHRoZSBudW1iZXJzIHJlY2VpdmVkXHJcbiAqIDguIEFkZCB0aGUgZmlyc3QgNSBwZXJtaXRhdGlvbnMgYXMgJ3Rocm93IGF3YXknIHBlcm1pdGF0aW9ucyAoaS5lLiB3aWxsIHVzdWFsbHkgYmUgc29tZXRoaW5nIGxpa2UgMTExMTExMSlcclxuICogOS4gQWZ0ZXIgdGhlIGZpcnN0IDUsIGNoZWNrIGlmIHRoZSBudW1iZXIgZXhpc3RzIGluIHRoZSBhcnJheSBvZiBFbmdsaXNoXHJcbiAqICAgIHdvcmRzIHByb3ZpZGVkIGJ5IHRoZSAnYW4tYXJyYXktb2YtZW5nbGlzaC13b3JkcycgcGFja2FnZSwgaWYgaXQgZG9lcywgXHJcbiAqICAgIGFkZCBpdCB0byB0aGUgdmFuaXR5TGlzdCBhcnJheVxyXG4gKiAxMC4gUHVsbCB0aGUgbGFzdCA1IG1hdGNoZXMgZnJvbSB0aGUgdmFuaXR5TGlzdFxyXG4gKiAxMS4gU3RvcmUgdGhvc2UgbWF0Y2hlcyBpbiB0aGUgZGF0YWJhc2VcclxuICogMTIuIFJldHVybiB0aGUgbWF0Y2hlcyAqIFxyXG4gKi9cclxuY29uc3QgZ2VuZXJhdGVWYW5pdHlQaG9uZU51bWJlcnMgPSBhc3luYyAobnVtYmVyOiBzdHJpbmcsIGRkYjogRHluYW1vREJEb2N1bWVudENsaWVudCk6IFByb21pc2U8c3RyaW5nW10+ID0+IHtcclxuICAgIGxldCB2YW5pdHlMaXN0OiBzdHJpbmdbXSA9IGF3YWl0IGNoZWNrRGF0YWJhc2UobnVtYmVyLCBkZGIpO1xyXG5cclxuICAgIGlmKHZhbml0eUxpc3QgIT0gdW5kZWZpbmVkICYmIHZhbml0eUxpc3QubGVuZ3RoID4gMCl7XHJcbiAgICAgICAgLy8gVGhlIHZhbml0eSBsaXN0IGFscmVhZHkgZXhpc3RzIGluIHRoZSBkYXRhYmFzZSwgc28gcmV0dXJuIGl0XHJcbiAgICAgICAgcmV0dXJuIHZhbml0eUxpc3Q7XHJcbiAgICB9XHJcblxyXG4gICAgdmFuaXR5TGlzdCA9IFtdO1xyXG5cclxuICAgIC8vIFB1bGxzIHRoZSBmaXJzdCB0aHJlZSBkaWdpdHMgZnJvbSB0aGUgcGhvbmUgbnVtYmVyXHJcbiAgICBjb25zdCBmaXJzdFRocmVlID0gbnVtYmVyLnNsaWNlKDAsMyk7XHJcbiAgICAvLyBQdWxscyB0aGUgbGFzdCBzZXZlbiBudW1iZXJzIGZyb20gdGhlIHBob25lIG51bWJlclxyXG4gICAgY29uc3QgbGFzdFNldmVuID0gbnVtYmVyLnNsaWNlKDMpLnNwbGl0KCcnKTsgICAgICAgIFxyXG5cclxuICAgIGNvbnN0IGxldHRlck1hcCA9IG5ldyBNYXAoW1xyXG4gICAgICAgIFsnMCcsICcwJ10sXHJcbiAgICAgICAgWycxJywgJzEnXSxcclxuICAgICAgICBbJzInLCAnQUJDJ10sXHJcbiAgICAgICAgWyczJywgJ0RFRiddLFxyXG4gICAgICAgIFsnNCcsICdHSEknXSxcclxuICAgICAgICBbJzUnLCAnSktMJ10sXHJcbiAgICAgICAgWyc2JywgJ01OTyddLFxyXG4gICAgICAgIFsnNycsICdQUVJTJ10sXHJcbiAgICAgICAgWyc4JywgJ1RVViddLFxyXG4gICAgICAgIFsnOScsICdXWFlaJ11cclxuICAgIF0pO1xyXG5cclxuICAgIGNvbnN0IHNwb3RPbmVTdHIgPSBsZXR0ZXJNYXAuZ2V0KGxhc3RTZXZlblswXSk/LnNwbGl0KCcnKSA7XHJcbiAgICBjb25zdCBzcG90VHdvU3RyID0gbGV0dGVyTWFwLmdldChsYXN0U2V2ZW5bMV0pPy5zcGxpdCgnJyk7XHJcbiAgICBjb25zdCBzcG90VGhyZWVTdHIgPSBsZXR0ZXJNYXAuZ2V0KGxhc3RTZXZlblsyXSk/LnNwbGl0KCcnKTtcclxuICAgIGNvbnN0IHNwb3RGb3VyU3RyID0gbGV0dGVyTWFwLmdldChsYXN0U2V2ZW5bM10pPy5zcGxpdCgnJyk7XHJcbiAgICBjb25zdCBzcG90Rml2ZVN0ciA9IGxldHRlck1hcC5nZXQobGFzdFNldmVuWzRdKT8uc3BsaXQoJycpO1xyXG4gICAgY29uc3Qgc3BvdFNpeFN0ciA9IGxldHRlck1hcC5nZXQobGFzdFNldmVuWzVdKT8uc3BsaXQoJycpO1xyXG4gICAgY29uc3Qgc3BvdFNldmVuU3RyID0gbGV0dGVyTWFwLmdldChsYXN0U2V2ZW5bNl0pPy5zcGxpdCgnJyk7XHJcblxyXG4gICAgLy8gQ2hlY2sgaWYgYW55IG9mIHRoZSBzdHJpbmcgYXJyYXlzIGFyZSBlbXB0eSwgd2hpY2ggbWVhbnMgdGhhdCB0aGUgbGFzdFNldmVuIGRpZG4ndCBwaWNrIHVwIGFsbCBvZiB0aGUgdmFsdWVzXHJcbiAgICBpZiggc3BvdE9uZVN0ciA9PSB1bmRlZmluZWQgfHwgc3BvdFR3b1N0ciA9PSB1bmRlZmluZWQgfHwgc3BvdFRocmVlU3RyID09IHVuZGVmaW5lZCB8fCBzcG90Rm91clN0ciA9PSB1bmRlZmluZWQgfHwgXHJcbiAgICAgICAgc3BvdEZpdmVTdHIgPT0gdW5kZWZpbmVkIHx8IHNwb3RTaXhTdHIgPT0gdW5kZWZpbmVkIHx8IHNwb3RTZXZlblN0ciA9PSB1bmRlZmluZWQgKXtcclxuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiVW5hYmxlIHRvIHJldHJpZXZlIGFsbCBudW1iZXIgc3RyaW5ncy5cIik7XHJcbiAgICAgICAgfVxyXG5cclxuICAgIC8vIExvb3AgdGhyb3VnaCBlYWNoIGdyb3VwcyBvZiBsZXR0ZXJzIHRvIGNyZWF0ZSBhIGNvbWJpbmF0aW9uIHN0cmluZyBmcm9tIGVhY2ggZ3JvdXAgb2YgbGV0dGVyc1xyXG4gICAgLy8gQXQgZWFjaCBpdGVyYXRpb24gYW5kIHN1YiBpdGVyYXRpb24sIHdlIGNoZWNrIHRvIHNlZSBpZiB0aGUgbGlzdCBoYXMgYmVlbiBjb21wbGV0ZWQgYW5kIGlmIHNvXHJcbiAgICAvLyAgYnJlYWsgb3V0IHRvIHRoZSBwcmV2aW91cyBsZXZlbCBcclxuICAgIGZvciggbGV0IGkgPSAwOyBpIDwgc3BvdE9uZVN0ci5sZW5ndGg7IGkrKyApe1xyXG4gICAgICAgIGlmKCB2YW5pdHlMaXN0Lmxlbmd0aCA+PSA1ICl7XHJcbiAgICAgICAgICAgIC8vIGxpc3QgYWxyZWFkeSBjb250YWlucyB0aGUgNSB3b3Jkc1xyXG4gICAgICAgICAgICBicmVhaztcclxuICAgICAgICB9XHJcbiAgICAgICAgXHJcbiAgICAgICAgZm9yICggbGV0IGogPSAwOyBqIDwgc3BvdFR3b1N0ci5sZW5ndGg7IGorKyApe1xyXG4gICAgICAgICAgICBpZiggdmFuaXR5TGlzdC5sZW5ndGggPj0gNSApe1xyXG4gICAgICAgICAgICAgICAgLy8gbGlzdCBhbHJlYWR5IGNvbnRhaW5zIHRoZSA1IHdvcmRzXHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgZm9yICggbGV0IGsgPSAwOyBrIDwgc3BvdFRocmVlU3RyLmxlbmd0aDsgaysrICl7XHJcbiAgICAgICAgICAgICAgICBpZiggdmFuaXR5TGlzdC5sZW5ndGggPj0gNSApe1xyXG4gICAgICAgICAgICAgICAgICAgIC8vIGxpc3QgYWxyZWFkeSBjb250YWlucyB0aGUgNSB3b3Jkc1xyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIGZvciAoIGxldCBtID0gMDsgbSA8IHNwb3RGb3VyU3RyLmxlbmd0aDsgbSsrICl7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYoIHZhbml0eUxpc3QubGVuZ3RoID49IDUgKXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gbGlzdCBhbHJlYWR5IGNvbnRhaW5zIHRoZSA1IHdvcmRzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgZm9yICggbGV0IG4gPSAwOyBuIDwgc3BvdEZpdmVTdHIubGVuZ3RoOyBuKysgKXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYoIHZhbml0eUxpc3QubGVuZ3RoID49IDUgKXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGxpc3QgYWxyZWFkeSBjb250YWlucyB0aGUgNSB3b3Jkc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvciAoIGxldCBwID0gMDsgcCA8IHNwb3RTaXhTdHIubGVuZ3RoOyBwKysgKXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmKCB2YW5pdHlMaXN0Lmxlbmd0aCA+PSA1ICl7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gbGlzdCBhbHJlYWR5IGNvbnRhaW5zIHRoZSA1IHdvcmRzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9yICggbGV0IHEgPSAwOyBxIDwgc3BvdFNldmVuU3RyLmxlbmd0aDsgcSsrICl7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYoIHZhbml0eUxpc3QubGVuZ3RoID49IDUgKXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gbGlzdCBhbHJlYWR5IGNvbnRhaW5zIHRoZSA1IHdvcmRzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgcGhvbmVXb3JkID0gc3BvdE9uZVN0cltpXSArIHNwb3RUd29TdHJbal0gKyBzcG90VGhyZWVTdHJba10gKyBzcG90Rm91clN0clttXSArIHNwb3RGaXZlU3RyW25dICsgc3BvdFNpeFN0cltwXSArIHNwb3RTZXZlblN0cltxXTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCB2YW5pdHlOdW1iZXIgPSBmaXJzdFRocmVlICsgcGhvbmVXb3JkO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmKCB3b3Jkcy5pbmNsdWRlcyhwaG9uZVdvcmQudG9Mb3dlckNhc2UoKSApICl7ICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIElmIHRoZSBjb21iaW5hdGlvbnMgb2YgbGV0dGVycyBmcm9tIHRoZSA3IGNoYXJhY3RlcnMgZm9ybXMgYSB3b3JkLCBhZGQgaXQgdG8gdGhlIGxpc3RcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFuaXR5TGlzdC5wdXNoKHZhbml0eU51bWJlcik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8vIElmIHRoZXJlIHdlcmUgbm8gY29tYmluYXRpb25zIGZvdW5kIHVzaW5nIHRoZSBmdWxsIHNldmVuIGRpZ2l0IHN0cmluZyxcclxuICAgIC8vIFdlJ2xsIGF0dGVtcHQgYSBzZWFyY2ggYmFzZWQgb24ganVzdCB0aGUgbGFzdCBmb3VyIGluc3RlYWRcclxuICAgIGlmKCB2YW5pdHlMaXN0Lmxlbmd0aCA9PSAwICkgeyAvLyBUaGUgZGVmYXVsdCBsaXN0IGxlbmd0aCBvZiBub25zZW5zZSBjb21iaW5hdGlvbnMgaXMgNyAgICAgICAgICAgICAgICBcclxuXHJcbiAgICAgICAgLy8gUHVsbHMgdGhlIGZpcnN0IHNpeCBkaWdpdHMgZnJvbSB0aGUgcGhvbmUgbnVtYmVyXHJcbiAgICAgICAgY29uc3QgZmlyc3RTaXggPSBudW1iZXIuc2xpY2UoMCw2KTtcclxuICAgICAgICAvLyBQdWxscyBvbmx5IHRoZSBsYXN0IGZvdXIgZGlnaXRzIGZyb20gdGhlIHBob25lIG51bWJlclxyXG4gICAgICAgIGNvbnN0IGxhc3RGb3VyID0gbnVtYmVyLnNsaWNlKDYpLnNwbGl0KCcnKTtcclxuXHJcbiAgICAgICAgY29uc3QgcmV0cnlTcG90T25lU3RyID0gbGV0dGVyTWFwLmdldChsYXN0Rm91clswXSk/LnNwbGl0KCcnKSA7XHJcbiAgICAgICAgY29uc3QgcmV0cnlTcG90VHdvU3RyID0gbGV0dGVyTWFwLmdldChsYXN0Rm91clsxXSk/LnNwbGl0KCcnKTtcclxuICAgICAgICBjb25zdCByZXRyeVNwb3RUaHJlZVN0ciA9IGxldHRlck1hcC5nZXQobGFzdEZvdXJbMl0pPy5zcGxpdCgnJyk7XHJcbiAgICAgICAgY29uc3QgcmV0cnlTcG90Rm91clN0ciA9IGxldHRlck1hcC5nZXQobGFzdEZvdXJbM10pPy5zcGxpdCgnJyk7XHJcblxyXG4gICAgICAgIC8vIENoZWNrIGlmIGFueSBvZiB0aGUgc3RyaW5nIGFycmF5cyBhcmUgZW1wdHksIHdoaWNoIG1lYW5zIHRoYXQgdGhlIGxhc3RTZXZlbiBkaWRuJ3QgcGljayB1cCBhbGwgb2YgdGhlIHZhbHVlc1xyXG4gICAgICAgIGlmKCByZXRyeVNwb3RPbmVTdHIgPT0gdW5kZWZpbmVkIHx8IHJldHJ5U3BvdFR3b1N0ciA9PSB1bmRlZmluZWQgfHwgcmV0cnlTcG90VGhyZWVTdHIgPT0gdW5kZWZpbmVkIHx8IHJldHJ5U3BvdEZvdXJTdHIgPT0gdW5kZWZpbmVkICl7XHJcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihcIlVuYWJsZSB0byByZXRyaWV2ZSBhbGwgbnVtYmVyIHN0cmluZ3MuXCIpO1xyXG4gICAgICAgIH0gXHJcblxyXG4gICAgICAgIC8vIExvb3AgdGhyb3VnaCBlYWNoIGNvbWJpbmF0aW9uIG9mIGRpZ2l0cyB0byBhdHRlbXB0IHRvIGZpbmQgd29yZHNcclxuICAgICAgICBmb3IoIGxldCBpID0gMDsgaSA8IHJldHJ5U3BvdE9uZVN0ci5sZW5ndGg7IGkrKyApe1xyXG4gICAgICAgICAgICAvLyBJZiB0aGUgdmFuaXR5IGxpc3QgaXMgZnVsbCwgd2UnbGwgc3RvcCB0aGUgbG9vcFxyXG4gICAgICAgICAgICBpZiggdmFuaXR5TGlzdC5sZW5ndGggPj0gNSApe1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIGZvciggbGV0IGogPSAwOyBqIDwgcmV0cnlTcG90VHdvU3RyLmxlbmd0aDsgaisrICl7XHJcbiAgICAgICAgICAgICAgICAvLyBJZiB0aGUgdmFuaXR5IGxpc3QgaXMgZnVsbCwgd2UnbGwgc3RvcCB0aGUgbG9vcFxyXG4gICAgICAgICAgICAgICAgaWYoIHZhbml0eUxpc3QubGVuZ3RoID49IDUgKXtcclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICBmb3IoIGxldCBrID0gMDsgayA8IHJldHJ5U3BvdFRocmVlU3RyLmxlbmd0aDsgaysrICl7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gSWYgdGhlIHZhbml0eSBsaXN0IGlzIGZ1bGwsIHdlJ2xsIHN0b3AgdGhlIGxvb3BcclxuICAgICAgICAgICAgICAgICAgICBpZiggdmFuaXR5TGlzdC5sZW5ndGggPj0gNSApe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGZvciggbGV0IG0gPSAwOyBtIDwgcmV0cnlTcG90Rm91clN0ci5sZW5ndGg7IG0rKyApe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBJZiB0aGUgdmFuaXR5IGxpc3QgaXMgZnVsbCwgd2UnbGwgc3RvcCB0aGUgbG9vcFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiggdmFuaXR5TGlzdC5sZW5ndGggPj0gNSApe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgcGhvbmVXb3JkID0gcmV0cnlTcG90T25lU3RyW2ldICsgcmV0cnlTcG90VHdvU3RyW2pdICsgcmV0cnlTcG90VGhyZWVTdHJba10gKyByZXRyeVNwb3RGb3VyU3RyW21dO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCB2YW5pdHlOdW1iZXIgPSBmaXJzdFNpeCArIHBob25lV29yZDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gSWYgdGhlIHZhbml0eSB3b3JkIGNyZWF0ZWQgYnkgdGhlIGxhc3QgZm91ciBkaWdpdHMgaXMgaW4gdGhlIHdvcmRzIGxpc3QsIGFkZCBpdCB0byB0aGUgdmFuaXR5IGxpc3RcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYoIHdvcmRzLmluY2x1ZGVzKHBob25lV29yZCkgKXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbml0eUxpc3QucHVzaCh2YW5pdHlOdW1iZXIpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIFxyXG4gICAgaWYoIHZhbml0eUxpc3QubGVuZ3RoID4gMCApe1xyXG4gICAgICAgIGNvbnNvbGUubG9nKCdHZW5lcmF0ZWQgdmFuaXR5IG51bWJlcnMhIFNhdmluZyB0byBkYjogJyArIHZhbml0eUxpc3QpO1xyXG4gICAgICAgIGF3YWl0IHNhdmUobnVtYmVyLCB2YW5pdHlMaXN0LCBkZGIpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgICB2YW5pdHlMaXN0LnB1c2goXCJXZSdyZSBzb3JyeSwgdGhlcmUgd2VyZSBubyB2YW5pdHkgbnVtYmVycyB0aGF0IG1hdGNoZWQgeW91ciBwaG9uZSBudW1iZXIuXCIpXHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIHZhbml0eUxpc3Q7XHJcbiAgXHJcbn1cclxuXHJcbi8qKlxyXG4gKiBGdW5jdGlvbiBuYW1lOiBjaGVja0RhdGFic2VcclxuICogQHBhcmFtIG51bWJlciBzdHJpbmdcclxuICogQHBhcmFtIGRkYiBEeW5hbW9EQkRvY3VtZW50Q2xpZW50XHJcbiAqIFxyXG4gKiBAcmV0dXJuIFByb21pc2U8c3RyaW5nW10+XHJcbiAqIFxyXG4gKiBJbnNpZGUgdGhlIGZ1bmN0aW9uOlxyXG4gKiAxLiBNYWtlcyBhIHJlcXVlc3QgdG8gdGhlIGRhdGFiYXNlIGZvciB0aGUgaW5jb21pbmcgcGhvbmUgbnVtYmVyXHJcbiAqICAgIHRvIHNlZSBpZiB0aGVyZSBpcyBhIHJlY29yZCBzdG9yZWQgYWxyZWFkeVxyXG4gKiAyLiBJZiB0aGVyZSBpcyBhIHJlY29yZCBhbHJlYWR5IHN0b3JlZCwgcmV0dXJuIHRoZSByZWNvcmRcclxuICogMy4gRWxzZSwgcmV0dXJuIGFuIGVtcHR5IGFycmF5IGluIHRoZSBwcm9taXNlXHJcbiAqL1xyXG5jb25zdCBjaGVja0RhdGFiYXNlID0gYXN5bmMgKG51bWJlcjogc3RyaW5nLCBkZGI6IER5bmFtb0RCRG9jdW1lbnRDbGllbnQpOiBQcm9taXNlPHN0cmluZ1tdPiA9PiBcclxueyAgIFxyXG4gICAgY29uc3QgcGFyYW1zID0ge1xyXG4gICAgICAgIFRhYmxlTmFtZTogJ3Zhbml0eV9udW1iZXJzJyxcclxuICAgICAgICBLZXk6IHtcclxuICAgICAgICAgICAgcGhvbmVfbnVtYmVyOiBudW1iZXJcclxuICAgICAgICB9XHJcbiAgICB9O1xyXG5cclxuICAgIGxldCByZXN1bHRzOiBzdHJpbmdbXSA9IFtdO1xyXG4gICBcclxuICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgZGRiLnNlbmQobmV3IEdldENvbW1hbmQocGFyYW1zKSk7XHJcbiAgICAgICAgaWYoIHJlc3VsdC5JdGVtPy52YW5pdHlfbnVtYmVycyAhPSB1bmRlZmluZWQgKXtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coJ0ZvdW5kIHZhbml0eSBudW1iZXJzIGluIGRiOiAnICsgcmVzdWx0Lkl0ZW0udmFuaXR5X251bWJlcnMpO1xyXG4gICAgICAgICAgICByZXN1bHRzID0gcmVzdWx0Lkl0ZW0/LnZhbml0eV9udW1iZXJzO1xyXG4gICAgICAgIH1cclxuICAgIH0gY2F0Y2goZXJyKXtcclxuICAgICAgICBjb25zb2xlLmVycm9yKGVycik7ICBcclxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJFbmNvdW50ZXJlZCBhbiBlcnJvciB3aGlsZSB0cnlpbmcgdG8gcmVxdWVzdCBleGlzdGluZyByZWNvcmRzOiBcIiArIGVycik7XHJcbiAgICB9IFxyXG5cclxuICAgIHJldHVybiByZXN1bHRzO1xyXG59XHJcblxyXG5cclxuLyoqXHJcbiAqIEZ1bmN0aW9uIG5hbWU6IHZhbml0eVBob25lTnVtYmVySGFuZGxlclxyXG4gKiBAcGFyYW0gZXZlbnQgQ29ubmVjdENvbnRhY3RGbG93RXZlbnRcclxuICogQHBhcmFtIGNvbnRleHQgQ29udGV4dFxyXG4gKiBcclxuICogQHJldHVybiBzdHJpbmdcclxuICogXHJcbiAqIEluc2lkZSB0aGUgZnVuY3Rpb246XHJcbiAqL1xyXG5leHBvcnQgY29uc3QgdmFuaXR5UGhvbmVOdW1iZXJIYW5kbGVyID0gYXN5bmMgKCBldmVudDogQ29ubmVjdENvbnRhY3RGbG93RXZlbnQsIGNvbnRleHQ6IENvbnRleHQsIGNhbGxiYWNrOiBDb25uZWN0Q29udGFjdEZsb3dDYWxsYmFjayApPT4ge1xyXG4gICAgQVdTLmNvbmZpZy51cGRhdGUoeyByZWdpb246IHByb2Nlc3MuZW52LkFXU19SRUdJT04gfSk7XHJcblxyXG4gICAgY29uc3QgZHluYW1vREIgPSBuZXcgRHluYW1vREJDbGllbnQoe30pO1xyXG4gICAgY29uc3QgZGRiID0gRHluYW1vREJEb2N1bWVudENsaWVudC5mcm9tKGR5bmFtb0RCKTtcclxuXHJcbiAgICB0cnkgeyBcclxuICAgICAgICBjb25zdCBwaG9uZU51bWJlciA9IGV2ZW50LkRldGFpbHM/LkNvbnRhY3REYXRhPy5DdXN0b21lckVuZHBvaW50Py5BZGRyZXNzO1xyXG4gICAgICAgIGlmKCBwaG9uZU51bWJlciA9PSB1bmRlZmluZWQpe1xyXG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ1VuYWJsZSB0byBnZXQgZXZlbnQgZGV0YWlscyBmcm9tIENvbm5lY3RDb250YWN0Rmxvd0V2ZW50Jyk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIFxyXG4gICAgICAgIGNvbnN0IHZhbGlkYXRlZE51bWJlciA9IHZhbGlkYXRlTnVtYmVyKHBob25lTnVtYmVyKTtcclxuXHJcbiAgICAgICAgY29uc3QgdmFuaXR5TGlzdCA9IGF3YWl0IGdlbmVyYXRlVmFuaXR5UGhvbmVOdW1iZXJzKHZhbGlkYXRlZE51bWJlciwgZGRiKTtcclxuXHJcbiAgICAgICAgY29uc3QgcmVzdWx0OiBDb25uZWN0Q29udGFjdEZsb3dSZXN1bHQgPSB7fTtcclxuXHJcbiAgICAgICAgY29uc3QgZmluYWxWYW5pdHlMaXN0ID0gdmFuaXR5TGlzdC5zbGljZSgtMyk7IC8vIFdlJ3JlIG9ubHkgcmV0dXJuaW5nIHRoZSBsYXN0IDUgbWF0Y2hlcyB0byB0aGUgdXNlclxyXG4gICAgICAgIFxyXG4gICAgICAgIGZvciAoIGxldCBpID0gMDsgaSA8IGZpbmFsVmFuaXR5TGlzdC5sZW5ndGg7IGkrKyApe1xyXG4gICAgICAgICAgICByZXN1bHRbJ251bWJlcicgKyBpXSA9IGZpbmFsVmFuaXR5TGlzdFtpXS5yZXBsYWNlKC8oLikvZywgJyQmLCAnKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGxldCBzdGF0dXMgPSAnJztcclxuICAgICAgICBpZiggcmVzdWx0WydudW1iZXIwJ10gIT09ICd1bmRlZmluZWQnKXtcclxuICAgICAgICAgICAgc3RhdHVzID0gJ1N1Y2Nlc3MhJztcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBzdGF0dXMgPSAnTm8gbWF0Y2hlcyBmb3VuZC4nO1xyXG4gICAgICAgIH1cclxuICAgICAgICBjYWxsYmFjayhudWxsLCByZXN1bHQpOyAgICAgICAgXHJcbiAgICAgICAgY29uc29sZS5sb2coc3RhdHVzKTtcclxuICAgICAgICByZXR1cm4gc3RhdHVzO1xyXG4gICAgfSBjYXRjaCAoZXJyKXtcclxuICAgICAgICBjb25zdCBzdGF0dXMgPSAnRmFpbHVyZSEnO1xyXG4gICAgICAgIGNvbnNvbGUubG9nKHN0YXR1cyk7XHJcbiAgICAgICAgY29uc29sZS5sb2coZXJyKTsgICAgICAgIFxyXG4gICAgICAgIGNhbGxiYWNrKGVyciBhcyBFcnJvcik7XHJcbiAgICAgICAgcmV0dXJuIHN0YXR1cztcclxuICAgIH1cclxufTtcclxuXHJcbiJdfQ==